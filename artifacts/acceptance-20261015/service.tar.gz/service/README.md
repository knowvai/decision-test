# Decision Evaluation Services

## Reviewed Native Deployments (2026-10-15)

The current 16-model scope is defined in
[the benchmark plan](../../../docs/plans/2026-10-14-decision-benchmark-plan.md),
not the historical launch examples below. `launch_reviewed.py` starts one model
at a time using the installed official worker/engine and a protected HTTP proxy.
It only replaces containers carrying its evaluation ownership label, refuses
occupied ports or other GPU compute processes, and never changes business services.
The retained preflight/legacy evaluation containers must be stopped explicitly
before rotating through the reviewed paths.

```sh
python3 launch_reviewed.py d3-mini --root "$EVAL_ROOT" --env-file "$EVAL_ENV_FILE"
python3 deployment_probe.py d3-mini --root "$EVAL_ROOT" --env-file "$EVAL_ENV_FILE"
```

Use the existing private evaluation env file; do not generate a new credential.
The public default is HTTP port 30889. Native engines bind only loopback 30888;
NeoHorse's backbone uses loopback 30887 behind its CPU-head adapter. The proxy
authenticates every route, including health, with the existing bearer key.
Generated secret files are owner-only and stay outside this repository. No TLS
is added. Changing the selected model changes the native API served at this
endpoint: SystemOne for worker/SDK models, `/v1/decide` for JEV, `/rerank` for
Qwen Reranker, and OpenAI chat completions for the ordinary Qwen LLM.

The runtime image extends the pinned preflight image without fetching packages:

```sh
docker build --network none -f Dockerfile.acceptance \
  -t decision-eval-runtime:acceptance-20261015 .
```

The launcher records the resolved image ID, commands and non-secret settings.
It disables decision result caches and vLLM prefix caching. SGLang's specialized
noncausal/joint-head path owns its required cache and chunking restrictions.
Models use the same eight-CPU budget; NeoHorse splits it between vLLM and CPUHead.
Single-card and TP=2 runs remain separate resource groups.
JEV defaults to native vLLM eager execution: the compiled profile produced NaN
on this pinned deployment, while eager passed the same synthetic checks. This
is an explicit configuration, not automatic inference fallback. The launcher
supports `--enforce-eager` for diagnostic runs of the other vLLM paths too.
Native checkpoint prefetch is enabled for vLLM/SGLang launches; it affects cold
loading only and must not be counted as a measured inference speed improvement.

For SDK backends, `SYSTEMONE_QUEUE_SINGLE_REQUESTS=1` opts into the existing
bounded queue at batch size one. Overflow returns 429 and expiration returns
504; serial execution explicitly reports no native batch. Defaults remain
unchanged for historical deployments. Jeva/Intern do not gain cross-request GPU
batching merely by enabling this queue. NeoHorse preserves the author's encoder
and CPUHead and batches encoded records through vLLM pooling, without replacing
its model head. Laya uses the official HTTP/batch application with a supported
input hook reusing the existing state/head/option truncation guard.

`deployment_probe.py` is a small synthetic transport/runtime check, not a second
benchmark runner. The legacy smoke script assumes older endpoint/length contracts;
this probe exercises the current native APIs, 18 options, single-versus-pool
outputs and the 49-request acceptance boundary. Probe timings include first-use
compilation and are not comparable performance results. The public-data runner
uses separate timing boundaries; the probe's default startup allowance is 2400
seconds for cold large-model loading, configurable with `--startup-timeout`.
Inference requests still have a separate 300-second deadline. The public-data runner
and the plan's limited engineering-pool tuning remain authoritative for formal
quality and latency measurements. Preserve failed probe attempts as well as the
latest result; no hidden retries, ranking or threshold selection occur here.

## Historical Deployment Examples

Everything below preserves earlier deployments and experiments. Their model
lists, ports, scheduler defaults and reranking protocols are not the current
reviewed configuration. Use the launcher and benchmark plan above for new runs.

Isolated text-only D3 mini/flash/edge, Clef-Flash, Intern-Decision-4B and
Laya multilingual services. Decision-2.0-Nox-4B remains in the `historical`
profile only for preserved older experiments. These call the
official decision runtimes, not vLLM generation. No 产品 production integration.

Models, SDK caches and runtime caches belong in a dedicated
directory on the large data disk, outside Docker's own storage subdirectories.
`EVAL_ROOT`, `DECISION_EVAL_API_KEY`, `LISTEN_ADDRESS` and ports come from a private
remote `.env`, never a committed credential. The default listen address is loopback.
Public access requires explicitly selecting a public bind address.

The user requested HTTP without TLS. Bearer credentials and request contents are
therefore transmitted in clear text. Use an independent evaluation credential,
non-sensitive data and a trusted network or SSH tunnel. This is not a production
transport-security recommendation. Secrets are never included in access logs.

Prepare each enabled service's writable `runtime/<service>` for UID 10001, then:

```sh
docker compose --env-file .env build clef
docker compose --env-file .env up -d --no-deps clef proxy
docker compose --env-file .env ps
```

For staged bring-up, start a ready model first. Once its authenticated health
check passes, `docker compose --env-file .env up -d --no-deps proxy` exposes that
model while the other returns 502 until ready. Docker DNS is resolved at request
time, so stopping or recreating one evaluation model does not strand the other.
The proxy has no model dependencies: operators must verify the selected model's
authenticated health before exposing it. Do not start all models together.

Intern and Laya use the `additional` profile and can be started explicitly after
their pinned weights have been downloaded. Proxy defaults are Clef 8082, Nox
8083 (historical), Intern 8084 and Laya 8085. D3 mini/flash/edge use 8087/8088/8089,
respectively, in the `current` profile. Verify availability before binding public ports.
Rotate only owned evaluation containers for single-model timing tests:

```sh
docker compose --env-file .env stop qwen clef nox intern laya d3-mini d3-flash d3-edge
docker compose --env-file .env up -d --no-deps intern proxy
```

`Dockerfile.extend` can extend an already verified base runtime image when
re-downloading CUDA dependencies is undesirable. It installs the same hash-pinned
Laya 0.4.1 wheel and server as the full Dockerfile. Record the resulting image ID.
This is an evaluation-only build option, not an application image change.

Both `/health` and `POST /v1/systemone` require `Authorization: Bearer <key>`.
`/v1/decisions` is a SystemOne alias, not the OpenAI Decisions wire protocol.
Request fields: `model`, `state`, `questions`. Question types: `choice`, `noul`,
`score`. Names: `clef-flash`, `Decision-2.0-Nox-4B`, `Intern-Decision-4B` and
`laya-multilingual`. Responses
preserve native answers and usage, adding wrapper `latency_ms`.

Example with an exported evaluation key and `DECISION_URL` set to the Nox HTTP
endpoint. For Clef, use its endpoint and change `model` to `clef-flash`:

```sh
curl "$DECISION_URL/v1/systemone" \
  -H "Authorization: Bearer $DECISION_EVAL_API_KEY" \
  -H 'Content-Type: application/json' \
  --data-binary '{
    "model": "Decision-2.0-Nox-4B",
    "state": "The item arrived damaged. The customer has a receipt and needs a replacement today.",
    "questions": {
      "route": {"type": "choice", "instructions": "Which team should handle this?", "criteria": {"returns": "Returns and damaged items", "billing": "Invoices and payments", "technical": "Software faults"}},
      "receipt": {"type": "noul", "instructions": "Does the customer have a receipt?"},
      "urgency": {"type": "score", "instructions": "When is action needed?", "criteria": ["Next month", "This week", "Today"]}
    }
  }'
```

Default bounds: 1 MiB body, four questions, 32 options, 2,048 input tokens per
encoded record. D3, Clef and Laya can coalesce compatible SystemOne HTTP
requests into one native GPU batch. The default is `SYSTEMONE_BATCH_SIZE=4`,
`SYSTEMONE_BATCH_WAIT_MS=2` and a bounded queue of 64 requests; set the batch
size to `1` to disable coalescing. The response records `batch_size`, queue
wait and native batch-call counters. Nox and Intern retain their single-request
path. Nox may return per-question
native errors, including `max_length_exceeded`; HTTP 200 is not proof of a valid
decision. Busy requests return 429; insufficient GPU allocation returns 503.
These are conservative coexistence settings, not full published context limits.
Single-model evaluation may explicitly set `MAX_INPUT_TOKENS=8192`; freeze and
record that setting for every candidate before timed runs. Intern rejects
overlength encoding natively. Laya is checked for state, instruction and option
truncation before its native SDK runs, including the SDK's 48-token option cap.

Use both models together for integration checks. For fair model latency tests,
stop the other *evaluation* model and record existing GPU workloads. Do not stop
the host's embedding service. Full quality, long-context and concurrent-load
evaluation remains separate from deployment smoke tests.

The verified baseline uses native PyTorch reference kernels when optional
`causal_conv1d` and `flash-linear-attention` are absent. Clef reported these
fallbacks on the target. They are correct but slower; this deployment smoke test
is not a vendor-optimized latency result. Pin and validate optimized kernels in
a separate configuration before drawing formal performance comparisons.

The runtime image pins PyTorch 2.9.1 CUDA 12.6 and Transformers 5.17.0; this
combination must be verified on the target GPU, and is not identical to every
vendor's published benchmark environment. Large downloads use ModelScope's SDK,
then official SHA-256 hashes. The public `model-lock.json` pins all four model
releases; stage its verified original small files outside the repository to
restore mirror differences. Provenance logs stay beside the remote deployment.

If the official torchvision index is unreachable, stage the matching official
CUDA wheel on a loopback-only HTTP server and build with
`--build-arg TORCHVISION_PACKAGE=http://127.0.0.1:<port>/<wheel> --network host`.
The default still uses the official index. `pip check` validates dependencies;
the local staging server must be stopped after the build.

## Jeva And Official Worker Preflight

`compose.preflight.yml` starts only Jeva and the existing proxy, in a separate
Compose project. It requires Compose 2.24.4 or later for override/reset tags.
Use the prebuilt `decision-eval-runtime:jeva-vela-preflight-20261015` image;
do not build the inherited reference Dockerfile under that image name.
`Dockerfile.preflight` expects an assembled build context containing `service/`,
the pinned `jeva-source/` and `vela-source/`, and the official causal-conv1d wheel
in `wheels/`. Exact revisions and the tested image ID are in the
[preflight record](../../../docs/research/2026-10-15-decision-three-model-preflight.md).

Set `EVAL_ROOT` to the evaluation data root containing `staging/jeva-4b`.
Prepare `preflight-20261015/runtime/jeva` beneath that root for UID 10001.
The private environment must contain the existing evaluation bearer key.

```sh
docker compose --env-file .env -f compose.preflight.yml config --quiet
docker compose --env-file .env -f compose.preflight.yml up -d --no-build jeva proxy
```

The model name is `Jeva-4B`; the existing request example and three question
types apply. `JEVA_GPU` defaults to GPU 0 and `JEVA_PORT` to 30881. Public
binding remains opt-in through `LISTEN_ADDRESS`. No TLS is added.
The official SDK handles inference; the thin adapter preserves values and maps
Score probability keys to ordinal strings. It disables result/option caches,
rejects truncation, and does not claim cross-request batching. This minimal
deployment uses one in-flight request; formal concurrency tuning is separate.

Vela was checked through its official `vllm-srun` worker, and NeoHorse through
the author's vLLM launcher plus CPU decision head. Those smoke services bind
only to loopback; they are not public, authenticated SystemOne frontends.

## Qwen3-Reranker-8B Reference

`compose.vllm.yml` optionally replaces only Qwen's serving engine with the
official vLLM v0.31.0 amd64 image pinned by digest. It reuses the original
weights, converts the classification head from `no`/`yes` at load time, and
uses the unmodified Apache-2.0 template from
[vLLM v0.31.0](https://github.com/vllm-project/vllm/blob/v0.31.0/examples/pooling/score/template/qwen3_reranker.jinja).
Launch it as an additional Compose override, after the appliance GPU override.
Validate CUDA compatibility and an independent full-pool smoke on the target
GPU before measuring. This file is configuration, not proof of target acceptance.

For this engine use the public benchmark's `--ranker-kind qwen
--rerank-transport vllm --tasks reranking`. It requests all documents without
truncation, restores results by index, and records actual whole-pool HTTP time.
The scheduler is capped at eight sequences; actual internal batch sizes and
forward counts are not exposed and remain unreported. The API differs from the
reference adapter below: omit `batch_size` and `questions`, and use `top_n` equal
to the document count. Missing, duplicate or invalid scores fail the entire pool.
The model API uses the evaluation bearer key; framework health endpoints may
be unauthenticated. There is no automatic fallback to the reference image.

Clef's optional `compose.sglang.yml` uses a separately tagged image built from
the pinned official `dev-clef` image. `Dockerfile.sglang` changes only the
joint-schema encoder's overflow handling: reject the complete request instead
of truncating state. The build asserts the upstream encoder SHA-256 before
applying this change. Record the image as **SGLang with strict-length guard**,
not an unmodified upstream benchmark. A100 acceptance is required separately.
The override preserves the official NVIDIA entrypoint and selects the image's
bundled CUDA compatibility libraries for the older evaluation driver. It does
not upgrade the host driver; actual CUDA and model acceptance remain required.
These official images run as UID 0, unlike the native adapter's UID 10001.
With `cap_drop: [ALL]`, a mode-0700 cache owned by UID 10001 is not writable
by that container root. Prepare each selected engine's dedicated runtime
directory for its actual UID; do not broaden permissions on model weights or
unrelated directories. The overrides redirect TorchInductor, FlashInfer and
SGLang JIT caches into `/runtime`; retain the read-only root filesystem.
Health checks use `python3`, which exists in both official images.
For Decision models, prefer the evaluation-only `/v1/rerank` adapter with
`--rerank-transport native_batch --batch-size 4`. It sends one complete pool
and performs independent query-passage records in one GPU batch, avoiding
thread-unsafe concurrent forwards and repeated HTTP overhead. `batch_size` is
an internal GPU batch size; it is not the same as HTTP request concurrency.
The service keeps `MAX_INFLIGHT_REQUESTS=1` by default. The
`systemone_concurrent` transport remains available as a diagnostic smoke test,
but increasing its client concurrency is not a production recommendation for
the reference D3 runtime.

The optional `qwen` service uses a separate `decision-eval-reranker:qwen3-bf16-v2`
image built with `Dockerfile.reranker` from the verified evaluation base. It adds
no dependencies and does not rebuild or retag the four existing decision images.
Its separate `qwen-reranker-lock.json` pins the official release; use the same
downloader with `--lock <path-to-qwen-reranker-lock.json> --model qwen3-reranker-8b`.
Weights and runtime caches remain under `EVAL_ROOT`. Native adapter caches use
UID 10001; the official vLLM/SGLang framework overrides use the image's actual
UID and redirect their compiler caches into the mounted runtime directory.

```sh
docker compose --env-file .env build qwen
docker compose --env-file .env up -d --no-deps qwen proxy
```

The Qwen proxy default is HTTP port 8086 (`QWEN_PORT`, same `LISTEN_ADDRESS`).
Authenticate `/health` and `POST /v1/rerank` with the existing independent
evaluation credential. This is a bounded evaluation wire contract, not an
assertion of compatibility with every hosted rerank SDK:

```sh
curl "$QWEN_RERANK_URL/v1/rerank" \
  -H "Authorization: Bearer $DECISION_EVAL_API_KEY" \
  -H 'Content-Type: application/json' \
  --data-binary '{
    "model": "Qwen3-Reranker-8B",
    "query": "What is the capital of China?",
    "documents": ["The capital of China is Beijing.", "Apples are fruit."],
    "batch_size": 8
  }'
```

Returns every input's `index` and `relevance_score` in input order, not just top-k;
the caller sorts scores. Fixed batch options are 1, 4 and 8, at most 128 nonempty
text documents and 1MiB HTTP body. Unknown fields (including `top_n`), wrong model,
and overlength encoded records fail with 422; oversized bodies fail with 413.
Qwen cannot answer decision requests. Decision pool scoring uses the separate
native adapter described below, not Qwen's yes/no score format.

The adapter follows the official Transformers prompt and yes/no logit softmax,
using BF16, SDPA, left padding, no KV cache or generation, and only final-position
logits. All records are validated against 8192 tokens before inference. There is
no truncation, CPU fallback, automatic OOM retry or hidden batch-size change.
`execution` reports batch size, forward count, encoded/padded tokens, synchronized
GPU inference time and peak allocated/reserved memory; `latency_ms` covers the
whole server operation. Gate and errors reuse the existing service; busy is 429,
GPU allocation failure is 503. Rate limiting is separately scoped to this pool
endpoint; there is no 0.21-second client pacing inside a pool.

Use a single resident evaluation model for comparative tests, preserving original
embedding and applications. Deployment smoke and complete-input compatibility
checks are not the formal five-model comparison or a production RAG improvement.

When rotating from a retained Qwen service to another candidate, stop `qwen`
explicitly using the updated Compose file. Historical v1 rotation scripts know
only the four decision containers and will not stop this new resident model;
do not reuse them unmodified for a purported single-model v2 performance run.

## Current Decision Pool Adapter

`Dockerfile.decision-v3` is a thin, offline build on the verified native runtime.
Place the official `laya-0.4.3-py3-none-any.whl` in the private build context;
the Dockerfile verifies its SHA-256 and installs it without changing dependencies.
Set `DECISION_RUNTIME_IMAGE` to its independently tagged image. Historical images
and weight locks are retained. The separate `d3-model-lock.json` pins the three
approved D3 releases; no nano/lite or 27B files are included. The downloader stages
fallback official files from `official-files/<model>` beside the selected lock.
Optional `modelscope_revision` pins the mirror revision; all final files must still
match official hashes. ModelScope SDK range-download concurrency may be configured
for acquisition only; it is not inference batch size.

Current candidates share `EVAL_GPU_FRACTION` (default 0.75) and
`EVAL_MODEL_MEMORY_LIMIT` (default 28g); these are allocation ceilings, not
reserved resources. Use sequential residency, never concurrent startup under
these ceilings. Record the resolved limits, original GPU workloads and input
token cap before freezing a comparison. Historical Nox retains its old limits
and is not part of the current comparison.

D3 uses its reviewed local `D3` runtime with BF16 backbone and FP32 readout. On
CUDA/A100 the AMD-specific `d3_fast` path is not enabled. Record actual optional
Gated DeltaNet kernels before treating timings as optimized performance.

The released D3-27B package contains about 52.17 GB of BF16 weights. Official
source checked on 2026-10-14 confirms single-device loading: `modeling_d3.py`
at `cbff3a3` rejects multi-device maps and treats `device_map="auto"` as the
default single device; `d3_runtime.py` at `2de0bdd` uses
`device_map={"": str(self.device)}`. The official HTTP server calls that runtime.
These unmodified BF16 paths cannot fit on a 40 GB A100 or pool two cards'
memory. This is source verification, not a recorded dual-A100 startup test.
Other native engine adaptations remain unverified; see the
[current evaluation plan](../../../docs/plans/2026-10-14-decision-benchmark-plan.md)
for source links and deployment status. A copied package is staged, not ready
for a formal inference result, until a startup smoke test passes.

Clef, Laya and D3 expose `POST /v1/rerank` with Qwen's query/documents/batch fields
plus a required `questions` object containing exactly one `relevance` score or
choice question. A choice question must contain a `relevant` criterion. Supply
the same frozen criteria for every decision candidate.
Each document sees only its own query/passage record; complete-pool validation
precedes any forward. The official encoders, model heads and probability decoding
remain authoritative. Scores are expected ordinal grade divided by maximum grade,
not calibrated relevance probabilities. Raw native answers are also returned.
The primary reranking question uses `score`, because its expected ordinal value
keeps useful ordering among irrelevant, partially useful and directly useful
passages. A binary `choice` (or `noul`) probability is a valid ablation for
binary labels, but it should not be selected solely to avoid the negligible
local expected-value calculation.

The adapter records actual GPU forward shapes through model hooks, not only an
HTTP request count. Laya's SDK CPU-OOM retry is explicitly prevented at the shared
HTTP execution boundary for both classification and reranking. Intern's
published cross-state batch path is not validated: its pool endpoint accepts
`batch_size=1` only and reports `independent_serial`; 4/8 are explicit 422 errors.
Do not interpret one packaged Intern HTTP request as one GPU forward.

The isolated proxy allows 100 requests/second with bounded burst and the model
gate still permits only one inference. All endpoints have a 300-second proxy
read timeout and 1MiB body bound; clients freeze their decision and pool timeouts
separately. This removes the old artificial five-requests/second pacing ceiling,
without changing production transport or application model settings.
