"""Acceptance must reject malformed native probabilities, not just HTTP errors."""

from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).parents[1] / "decision-eval"))
from deployment_probe import valid_probabilities


class ProbabilityValidationTests(unittest.TestCase):
    def test_complete_finite_distribution(self):
        self.assertTrue(valid_probabilities({"yes": 0.8, "no": 0.2}, ["yes", "no"]))

    def test_invalid_distributions(self):
        for value in ({"yes": 1}, {"yes": float("nan"), "no": 0},
                      {"yes": 0.4, "no": 0.4}, {"yes": True, "no": False},
                      {"yes": -0.1, "no": 1.1}, [0.8, 0.2]):
            with self.subTest(value=value):
                self.assertFalse(valid_probabilities(value, ["yes", "no"]))


if __name__ == "__main__":
    unittest.main()
