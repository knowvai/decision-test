import os

if os.environ.get("JEV_NUMERIC_DIAGNOSTIC") == "1":
    import json
    import torch
    from vllm.lora.layers.base_linear import BaseLinearLayerWithLoRA
    from vllm.lora.layers.logits_processor import LogitsProcessorWithLoRA

    _seen = set()

    def check(name, values):
        if name in _seen:
            return
        tensors = []
        for value in values:
            if isinstance(value, (tuple, list)):
                tensors.extend(v for v in value if isinstance(v, torch.Tensor))
            elif isinstance(value, torch.Tensor):
                tensors.append(value)
        bad = [dict(shape=list(t.shape), dtype=str(t.dtype),
                    nonfinite=int((~torch.isfinite(t)).sum()))
               for t in tensors if not bool(torch.isfinite(t).all())]
        if bad:
            _seen.add(name)
            print("JEV_NUMERIC " + json.dumps(dict(pid=os.getpid(), stage=name, tensors=bad)), flush=True)

    _linear = BaseLinearLayerWithLoRA._apply_lora_to_output

    def linear(self, x, output):
        name = getattr(self.base_layer, "prefix", type(self).__name__)
        check(name + ":before", [x, output, self.lora_a_stacked, self.lora_b_stacked])
        result = _linear(self, x, output)
        check(name + ":after", [result])
        return result

    BaseLinearLayerWithLoRA._apply_lora_to_output = linear
    _logits = LogitsProcessorWithLoRA._get_logits

    def logits(self, hidden, *args, **kwargs):
        check("logits:before", [hidden, self.lora_a_stacked, self.lora_b_stacked])
        result = _logits(self, hidden, *args, **kwargs)
        check("logits:after", [result])
        return result

    LogitsProcessorWithLoRA._get_logits = logits
    print("JEV_NUMERIC enabled pid=" + str(os.getpid()), flush=True)
