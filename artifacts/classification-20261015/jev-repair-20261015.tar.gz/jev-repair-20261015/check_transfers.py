"""Independent adapter copy validation; no model inference or scored data."""
import gc
import hashlib
import json
import os
from pathlib import Path

import torch
import vllm
from vllm.lora.lora_model import LoRAModel
from vllm.lora.peft_helper import PEFTHelper

path = Path("/model/adapter_vllm")
config = json.loads((path / "adapter_config.json").read_text())
report = {"torch": torch.__version__, "vllm": vllm.__version__,
          "scope": "CPU/GPU adapter tensor equality only; no inference",
          "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "rounds": []}
for disabled in (False, True):
    os.environ["VLLM_LORA_DISABLE_PIN_MEMORY"] = "1" if disabled else "0"
    for iteration in range(3):
        model = LoRAModel.from_local_checkpoint(
            str(path), set(config["target_modules"]), PEFTHelper.from_dict(config),
            device="cpu", dtype=torch.bfloat16)
        for device in (0, 1):
            torch.cuda.set_device(device)
            row = {"disable_pin_memory": disabled, "iteration": iteration, "gpu": device,
                   "checked": 0, "pinned": 0, "bad": []}
            for name, layer in model.loras.items():
                for field in ("lora_a", "lora_b"):
                    source = getattr(layer, field)
                    target = torch.empty_like(source, device="cuda")
                    target.copy_(source, non_blocking=True)
                    torch.cuda.synchronize()
                    back = target.cpu()
                    row["checked"] += 1
                    row["pinned"] += int(source.is_pinned())
                    if not torch.equal(source, back):
                        # Recopy through ordinary CPU memory to isolate DMA from math.
                        clone = source.clone()
                        control = clone.to("cuda").cpu()
                        row["bad"].append({"module": name, "tensor": field,
                            "elements": int((source != back).sum()),
                            "cpu_finite": bool(torch.isfinite(source).all()),
                            "gpu_nonfinite": int((~torch.isfinite(back)).sum()),
                            "pageable_control_equal": torch.equal(clone, control)})
            report["rounds"].append(row)
            print(json.dumps({k: v for k, v in row.items() if k != "bad"} |
                             {"bad_tensors": len(row["bad"])}), flush=True)
        del model, source, target, back
        gc.collect()
report["fixed_pass"] = all(r["checked"] == 802 and not r["pinned"] and not r["bad"]
                           for r in report["rounds"] if r["disable_pin_memory"])
report["baseline_reproduced"] = any(r["bad"] for r in report["rounds"] if not r["disable_pin_memory"])
Path("/evidence/transfer-validation.json").write_text(json.dumps(report, indent=2) + "\n")
assert report["fixed_pass"], "Pageable transfer verification failed"
