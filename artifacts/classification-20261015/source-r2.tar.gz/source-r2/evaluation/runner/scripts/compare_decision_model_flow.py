"""Compare two Supervisor conversation endpoints with the same end-to-end inputs."""

from __future__ import annotations

import argparse
import json
import re
import statistics
import sys
import time
from dataclasses import asdict, dataclass, field
from typing import Any

import httpx


DEFAULT_QUESTIONS = [
    "请用一句话回答：2 加 2 等于多少？",
    "请根据授权知识库中的相关资料总结主要要点，并给出引用。",
]


@dataclass
class TurnResult:
    endpoint: str
    question: str
    status_code: int = 0
    elapsed_ms: float = 0.0
    first_event_ms: float | None = None
    first_content_ms: float | None = None
    terminal_status: str = ""
    answer_chars: int = 0
    answer_preview: str = ""
    answer: str = ""
    references: list[dict[str, Any]] = field(default_factory=list)
    usage: dict[str, Any] = field(default_factory=dict)
    reference_count: int = 0
    route: str = ""
    needs_rag: bool | None = None
    event_types: list[str] = field(default_factory=list)
    error: str = ""
    _content_parts: list[str] = field(default_factory=list, repr=False)


def _headers(tenant_id: str, user_id: str) -> dict[str, str]:
    return {
        "Accept": "text/event-stream",
        "Content-Type": "application/json",
        "X-Tenant-ID": tenant_id,
        "X-User-ID": user_id,
    }


def _decode_sse_data(buffer: str) -> tuple[list[dict[str, Any]], str]:
    events: list[dict[str, Any]] = []
    # Keep the entire unfinished frame, not only its last unfinished line.
    frames = re.split(r"\r\n\r\n|\n\n|\r\r", buffer)
    for frame in frames[:-1]:
        data_lines = [line[5:].removeprefix(" ") for line in frame.splitlines() if line.startswith("data:")]
        if not data_lines:
            continue
        payload = "\n".join(data_lines)
        if payload == "[DONE]":
            events.append({"type": "done", "status": "completed"})
            continue
        try:
            value = json.loads(payload)
        except json.JSONDecodeError:
            value = {"type": "malformed", "raw": payload[:200]}
        if isinstance(value, dict):
            events.append(value)
    return events, frames[-1]


def _apply_event(result: TurnResult, event: dict[str, Any]) -> None:
    event_type = str(event.get("type") or event.get("event") or "").strip()
    if event_type and event_type not in result.event_types:
        result.event_types.append(event_type)
    routing = event.get("routing_decision")
    if event_type in {"smart_router", "router", "routing_decision"} or isinstance(routing, dict):
        result.route = str(
            event.get("execution_mode")
            or event.get("route")
            or (routing or {}).get("execution_mode")
            or ""
        )
        if "needs_rag" in event:
            result.needs_rag = bool(event["needs_rag"])
        elif isinstance(routing, dict) and "needs_rag" in routing:
            result.needs_rag = bool(routing["needs_rag"])
    if event_type in {"done", "complete", "generation_complete"}:
        result.terminal_status = str(event.get("status") or event.get("finish_reason") or "completed")
    if event_type == "error":
        result.error = str(event.get("message") or event.get("code") or "stream_error")
    if event_type == "malformed":
        result.error = result.error or "malformed_sse_event"
    if event_type in {"content", "answer_delta", "message", "delta"}:
        content = event.get("content") or event.get("delta") or event.get("text") or ""
        result._content_parts.append(str(content))
    if event_type in {"final_answer", "answer_replace"} and isinstance(event.get("answer"), str):
        result._content_parts = [event["answer"]]
    choices = event.get("choices")
    if isinstance(choices, list):
        for choice in choices:
            if not isinstance(choice, dict):
                continue
            delta = choice.get("delta") or choice.get("message") or {}
            if isinstance(delta, dict):
                result._content_parts.append(str(delta.get("content") or ""))
            if choice.get("finish_reason"):
                result.terminal_status = str(choice["finish_reason"])
    references = event.get("references") or event.get("sources")
    if isinstance(references, list):
        result.reference_count = max(result.reference_count, len(references))
        result.references = references
    if isinstance(event.get("usage"), dict):
        result.usage.update(event["usage"])
    if event_type == "phase" and event.get("phase") == "complete" and event.get("status") == "completed":
        result.terminal_status = "completed"
        data = event.get("data") or {}
        if isinstance(data.get("usage"), dict):
            result.usage.update(data["usage"])


def _finalize_result(result: TurnResult) -> TurnResult:
    raw = "".join(result._content_parts)
    visible = re.sub(r"<think>.*?</think>", "", raw, flags=re.IGNORECASE | re.DOTALL)
    visible = visible.replace("<think>", "").replace("</think>", "").strip()
    result.answer_chars = len(visible)
    result.answer_preview = visible[:400]
    result.answer = visible
    if not result.terminal_status:
        result.terminal_status = "incomplete"
        result.error = result.error or "stream_ended_without_terminal_event"
    return result


def create_conversation(
    client: httpx.Client,
    endpoint: str,
    tenant_id: str,
    user_id: str,
    kb_id: str,
) -> str:
    response = client.post(
        f"{endpoint.rstrip('/')}/apis/agents/v1/tenants/{tenant_id}/conversations",
        headers={"Content-Type": "application/json", "X-User-ID": user_id, "X-Tenant-ID": tenant_id},
        json={
            "title": "decision-model-flow-comparison",
            "retrieval": {"all_of": [{"any_of": [{"kb_id": kb_id}]}]},
        },
    )
    response.raise_for_status()
    return str(response.json()["id"])


def run_turn(
    client: httpx.Client,
    endpoint: str,
    tenant_id: str,
    user_id: str,
    kb_id: str,
    question: str,
) -> TurnResult:
    result = TurnResult(endpoint=endpoint, question=question)
    started = time.perf_counter()
    try:
        conversation_id = create_conversation(client, endpoint, tenant_id, user_id, kb_id)
        with client.stream(
            "POST",
            f"{endpoint.rstrip('/')}/apis/agents/v1/tenants/{tenant_id}/conversations/{conversation_id}/messages",
            headers=_headers(tenant_id, user_id),
            json={"message": question, "stream": True, "use_cache": False},
        ) as response:
            result.status_code = response.status_code
            response.raise_for_status()
            first = True
            pending = ""
            for chunk in response.iter_text():
                if first and chunk:
                    result.first_event_ms = (time.perf_counter() - started) * 1000
                    first = False
                pending += chunk
                events, pending = _decode_sse_data(pending)
                for event in events:
                    before = len(result._content_parts)
                    _apply_event(result, event)
                    if result.first_content_ms is None and any(result._content_parts[before:]):
                        result.first_content_ms = (time.perf_counter() - started) * 1000
    except Exception as exc:  # noqa: BLE001 - comparison must retain failed cases
        result.error = f"{type(exc).__name__}: {exc}"[:400]
    result.elapsed_ms = (time.perf_counter() - started) * 1000
    return _finalize_result(result)


def run_stateless_turn(
    client: httpx.Client,
    endpoint: str,
    tenant_id: str,
    user_id: str,
    kb_id: str,
    question: str,
) -> TurnResult:
    """Run the complete stateless Supervisor/OpenAI-compatible pipeline."""
    result = TurnResult(endpoint=endpoint, question=question)
    started = time.perf_counter()
    try:
        payload = {
            "tenant_id": tenant_id,
            "model_stage": "model.binding.conversation.generation",
            "messages": [{"role": "user", "content": question}],
            "stream": True,
            "thinking": True,
        }
        if kb_id:
            payload["filters"] = {"all_of": [{"any_of": [{"kb_id": kb_id}]}]}
            payload["cache_scope"] = {"tenant_id": tenant_id, "kb_ids": [kb_id]}
        with client.stream(
            "POST",
            f"{endpoint.rstrip('/')}/apis/agents/v1/openai/chat/completions",
            headers={
                "Accept": "text/event-stream",
                "Content-Type": "application/json",
                "X-Tenant-ID": tenant_id,
                "X-User-ID": user_id,
            },
            json=payload,
        ) as response:
            result.status_code = response.status_code
            response.raise_for_status()
            first = True
            pending = ""
            for chunk in response.iter_text():
                if first and chunk:
                    result.first_event_ms = (time.perf_counter() - started) * 1000
                    first = False
                pending += chunk
                events, pending = _decode_sse_data(pending)
                for event in events:
                    before = len(result._content_parts)
                    _apply_event(result, event)
                    if result.first_content_ms is None and any(result._content_parts[before:]):
                        result.first_content_ms = (time.perf_counter() - started) * 1000
    except Exception as exc:  # noqa: BLE001 - comparison must retain failed cases
        result.error = f"{type(exc).__name__}: {exc}"[:400]
    result.elapsed_ms = (time.perf_counter() - started) * 1000
    return _finalize_result(result)


def _summary(results: list[TurnResult]) -> dict[str, Any]:
    by_endpoint: dict[str, list[TurnResult]] = {}
    for result in results:
        by_endpoint.setdefault(result.endpoint, []).append(result)
    summary: dict[str, Any] = {}
    for endpoint, values in by_endpoint.items():
        elapsed = [item.elapsed_ms for item in values]
        first = [item.first_event_ms for item in values if item.first_event_ms is not None]
        summary[endpoint] = {
            "turns": len(values),
            "completed": sum(item.terminal_status in {"completed", "stop"} and not item.error and item.answer_chars > 0 for item in values),
            "errors": sum(bool(item.error) for item in values),
            "mean_elapsed_ms": round(statistics.mean(elapsed), 1) if elapsed else None,
            "p50_elapsed_ms": round(statistics.median(elapsed), 1) if elapsed else None,
            "mean_first_event_ms": round(statistics.mean(first), 1) if first else None,
            "mean_answer_chars": round(statistics.mean(item.answer_chars for item in values), 1),
            "mean_reference_count": round(statistics.mean(item.reference_count for item in values), 1),
        }
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline-url", required=True)
    parser.add_argument("--candidate-url", required=True)
    parser.add_argument("--tenant-id", required=True)
    parser.add_argument("--user-id", required=True)
    parser.add_argument("--kb-id", required=True)
    parser.add_argument("--questions-json", default="")
    parser.add_argument("--question", action="append", default=[])
    parser.add_argument("--repeat", type=int, default=1)
    parser.add_argument("--mode", choices=("conversation", "stateless"), default="conversation")
    parser.add_argument("--timeout-seconds", type=float, default=180.0)
    parser.add_argument("--output", default="")
    args = parser.parse_args()
    questions = (
        list(args.question)
        if args.question
        else (json.loads(args.questions_json) if args.questions_json else DEFAULT_QUESTIONS)
    )
    questions = questions * max(1, args.repeat)
    if not isinstance(questions, list) or not all(isinstance(item, str) and item.strip() for item in questions):
        parser.error("--questions-json must be a JSON string array")

    results: list[TurnResult] = []
    with httpx.Client(timeout=httpx.Timeout(args.timeout_seconds)) as client:
        for question in questions:
            for endpoint in (args.baseline_url, args.candidate_url):
                runner = run_stateless_turn if args.mode == "stateless" else run_turn
                results.append(runner(client, endpoint, args.tenant_id, args.user_id, args.kb_id, question))
    rendered_results = []
    for item in results:
        value = asdict(item)
        value.pop("_content_parts", None)
        rendered_results.append(value)
    payload = {"results": rendered_results, "summary": _summary(results)}
    rendered = json.dumps(payload, ensure_ascii=False, indent=2)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as handle:
            handle.write(rendered + "\n")
    print(rendered)
    return 0 if all(not item.error for item in results) else 2


if __name__ == "__main__":
    sys.exit(main())
