"""Offline supplemental audit; no inference or mutation of existing evidence."""
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import statistics
import subprocess
import sys

ROOT = Path('/data/sdb/decision-model-eval/classification-20261015')
SOURCE = ROOT / 'source-r7'
EVIDENCE = ROOT / 'qwen38-supplement-20261016'
MODEL = 'qwen3.8-27b'
REFERENCE = 'qwen3-30b-a3b-instruct-2507'
IMAGE = 'sha256:c76d0e2225a4b1cb1e2109ace39639f55e714abd1a7a427acc8b0bbd7f6a83b3'
REVISION = '1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0'
PRIOR_SHA = '4accc5327368197a99b9aa04b9c48751026b3ecfa8ad1be9b20c4b21e7e60729'
sys.path.insert(0, str(SOURCE / 'evaluation/runner/scripts'))
sys.path.insert(0, str(SOURCE / 'deploy/docker/decision-eval'))
import public_decision_benchmark as bench
from launch_reviewed import MODELS

def read(path):
    return json.loads(path.read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

artifacts = {}

def track(path):
    artifacts[str(path)] = sha(path)

def verify_prior():
    assert sha(ROOT / 'audit-20261015/summary.json') == PRIOR_SHA
    prior = read(ROOT / 'audit-20261015/summary.json')
    assert len(prior['artifact_sha256']) == 98
    assert all(sha(Path(p)) == v for p, v in prior['artifact_sha256'].items())
    assert prior['total_models'] == 14
    return prior

prior = verify_prior()
preparation = read(EVIDENCE / 'preparation.json')
assert preparation['prior_audit_sha256'] == PRIOR_SHA
for path, expected in preparation['source_sha256'].items():
    assert sha(SOURCE / path) == expected, ('prepared_source', path)
    track(SOURCE / path)
names = set(preparation['inference_timing_scoring_ast_equal']) | {'classification_schema'}
def functions(path):
    result = {n.name: ast.dump(n, include_attributes=False)
              for n in ast.parse(path.read_text()).body
              if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name in names}
    assert set(result) == names
    return result
runner = Path('evaluation/runner/scripts/public_decision_benchmark.py')
assert functions(SOURCE / runner) == functions(ROOT / 'source-r6' / runner)

dataset = ROOT / 'dataset'
dataset_protocol = read(dataset / 'dataset-protocol.private.json')
for name, field in [('inputs.private.jsonl', 'inputs_sha256'),
                    ('labels.private.jsonl', 'labels_sha256'),
                    ('preflight.inputs.private.jsonl', 'preflight_sha256')]:
    assert sha(dataset / name) == dataset_protocol[field]
    track(dataset / name)
track(dataset / 'dataset-protocol.private.json')
inputs = [x for x in bench.read_jsonl(dataset / 'inputs.private.jsonl') if x['task'] == 'classification']
labels = [x for x in bench.read_jsonl(dataset / 'labels.private.jsonl') if x['task'] == 'classification']
gold = {x['case_id']: x['gold'] for x in labels}
assert len(inputs) == len(labels) == len(gold) == 2974
groups = {x['case_id']: bench.digest(x['state']) for x in inputs}
assert len(set(groups.values())) == 2921
assert set(gold.values()) == set(bench.DOMAINS)
assert dataset_protocol['domain_questions'] == bench.DOMAIN_QUESTIONS

directory = ROOT / 'run-007'
protocol = read(directory / 'protocol.private.json')
status = read(directory / 'status.json')
assert status['state'] == 'complete' and status['completed'] == status['models'] == [MODEL]
assert protocol['models'] == [MODEL]
assert protocol['parent_dataset_protocol'] == bench.digest(dataset_protocol)
old_protocol = read(ROOT / 'run-001/protocol.private.json')
invariant = lambda p: {k: v for k, v in p.items() if k not in ('models', 'source_sha256', 'predecessor')}
assert invariant(protocol) == invariant(old_protocol)
assert protocol['records'] == 2974 and protocol['concurrency'] == protocol['repeats'] == 1
assert protocol['retries'] == 0 and not protocol['fallback'] and not protocol['truncation']
assert protocol['timeout_seconds'] == 300 and not protocol['labels_sent']
assert protocol['llm'] == {'method': 'json_schema', 'strict': True, 'temperature': 0, 'max_tokens': 64}
assert protocol['predecessor'] == bench.classification_predecessor(ROOT / 'run-006', [MODEL], extend_roster=True)
assert set(protocol['predecessor']['roster_extension']['completed_models']) == {m['model'] for m in prior['models']}
for path, expected in protocol['source_sha256'].items():
    assert sha(Path(path)) == expected
    track(Path(path))
packages = read(directory / 'client-packages.json')
assert all(packages[k] == v for k, v in protocol['client_packages'].items())
for name in ('protocol.private.json', 'status.json', 'client-packages.json'):
    track(directory / name)

d = directory / MODEL
for name in ('deployment.json', 'summary.json', 'responses.private.jsonl', 'warmup.private.json'):
    assert (d / name).is_file()
    track(d / name)
deployment = read(d / 'deployment.json')
assert deployment['model'] == MODEL and deployment['family'] == 'llm'
assert deployment['served_model'] == MODELS[MODEL][2] == 'Qwen3.8-27B'
assert deployment['tp'] == 2 and deployment['cpu_budget'] == 8
assert deployment['image_id'] == IMAGE
assert subprocess.check_output(['docker', 'image', 'inspect', IMAGE, '--format', '{{.Id}}'], text=True).strip() == IMAGE
service = SOURCE / 'deploy/docker/decision-eval'
for path, expected in deployment['source_sha256'].items():
    assert sha(service / path) == expected
    track(service / path)
command = deployment['command']
for flag, value in {'--model': '/model', '--served-model-name': 'Qwen3.8-27B',
                    '--dtype': 'bfloat16', '--tensor-parallel-size': '2',
                    '--max-model-len': '8192', '--max-num-seqs': '16',
                    '--max-num-batched-tokens': '16384'}.items():
    assert command[command.index(flag) + 1] == value
assert '--language-model-only' in command and '--no-enable-prefix-caching' in command
assert json.loads(command[command.index('--default-chat-template-kwargs') + 1]) == {'enable_thinking': False}
assert not any(x in command for x in ('--quantization', '--cpu-offload-gb', '--enable-lora'))
assert not any(k.startswith('VLLM_LORA') for k in deployment.get('env', {}))

synthetic = next(x for x in bench.read_jsonl(dataset / 'preflight.inputs.private.jsonl') if x['task'] == 'classification')
warmup_inputs = [{**synthetic, 'case_id': 'synthetic:classification:' + str(length),
                 'state': {'utterance': synthetic['state']['utterance'] * length}} for length in (1, 16, 64)] * 3
warmups = read(d / 'warmup.private.json')
assert len(warmups) == 9 and [x['input'] for x in warmups] == warmup_inputs
rows = bench.read_jsonl(d / 'responses.private.jsonl')
assert len(rows) == len({x['case_id'] for x in rows}) == 2974
assert [x['case_id'] for x in rows] == [x['case_id'] for x in inputs]
for job, row in zip(inputs, rows):
    assert row['input_sha256'] == bench.digest(job)
    assert row['task'] == 'classification' and row['repeat'] == 1
    assert row['status'] in ('valid', 'failed')
    assert math.isfinite(row['elapsed_ms']) and row['elapsed_ms'] >= 0
for job, row in [(x['input'], x['result']) for x in warmups] + list(zip(inputs, rows)):
    if row.get('status') == 'failed':
        continue
    assert row['prediction'] in bench.DOMAINS
    assert len(row['calls']) == 1
    call = row['calls'][0]
    assert call['status'] == 'valid' and call['kind'] == 'structured_llm_classification'
    assert call['input_sha256'] == bench.digest({'messages': bench.domain_messages(job['state'], bench.DOMAIN_QUESTIONS)})
    assert call['result']['reported_model'] == deployment['served_model']
    assert call['result']['prediction'] == row['prediction']
    assert math.isfinite(call['client_elapsed_ms']) and call['client_elapsed_ms'] >= 0
    usage = call['result']['usage']
    assert 0 < usage['output_tokens'] <= 64
    assert usage['total_tokens'] == usage['input_tokens'] + usage['output_tokens']
    assert usage['total_tokens'] <= 8192

recomputed = bench.local_classification_summary(inputs, labels, rows)
assert read(d / 'summary.json') == dict(recomputed, model=MODEL)
predicted = {x['case_id']: x['prediction'] for x in rows if x['status'] == 'valid'}
correct = sum(predicted.get(k) == v for k, v in gold.items())
assert recomputed['accuracy'] == correct / 2974
f1s = []
for label in bench.DOMAINS:
    tp = sum(gold[k] == label and v == label for k, v in predicted.items())
    fp = sum(gold[k] != label and v == label for k, v in predicted.items())
    fn = sum(v == label and predicted.get(k) != label for k, v in gold.items())
    f1s.append(2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0)
assert math.isclose(statistics.mean(f1s), recomputed['macro_f1'], abs_tol=1e-14)
times = sorted(x['elapsed_ms'] for x in rows if x['status'] == 'valid')
assert recomputed['valid_output_rate'] == len(times) / 2974
pos = (len(times) - 1) * .99
p99 = times[math.floor(pos)] * (1 - pos % 1) + times[math.ceil(pos)] * (pos % 1)
assert math.isclose(p99, recomputed['successful_task_latency']['p99_ms'], abs_tol=1e-10)
assert statistics.mean(times) == recomputed['successful_task_latency']['mean_ms']
expected = {(m['run'], m['model']) for m in prior['models']} | {('run-007', MODEL)}
actual = {(p.parent.parent.name, p.parent.name) for p in ROOT.glob('run-*/*/responses.private.jsonl')}
assert len(expected) == len({m for _, m in expected}) == 15 and actual == expected
assert not any(list((ROOT / run).rglob('responses.private.jsonl')) for run in ('run-004', 'run-005'))

manifest = read(EVIDENCE / 'model-manifest.json')['models'][0]
assert manifest['model'] == 'Qwen/Qwen3.8-27B' and manifest['hf_revision'] == REVISION
model_path = ROOT.parent / 'staging' / MODEL
assert len(manifest['files']) == 32
assert sum(x['size'] for x in manifest['files'].values()) == 55586114863
for name, metadata in manifest['files'].items():
    path = model_path / name
    assert path.stat().st_size == metadata['size']
    if name.endswith('.json'):
        read(path)
    if not name.endswith('.safetensors'):
        content = path.read_bytes()
        if metadata['lfs']:
            assert hashlib.sha256(content).hexdigest() == metadata['lfs']['sha256']
        else:
            assert hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest() == metadata['blob_id']
index = read(model_path / 'model.safetensors.index.json')
assert set(index['weight_map'].values()) == {n for n in manifest['files'] if n.endswith('.safetensors')}
assert len(set(index['weight_map'].values())) == 18
probe = read(EVIDENCE / 'accepted-probe.json')
assert probe['accepted'] and probe['ready']['status'] == 200
assert [x['status'] for x in probe['auth']] == [401, 401, 401]
assert probe['overlength']['status'] == 400
probed = [probe['classification'], *probe['singles'], *probe['pool']]
assert len(probed) == 6 and len(probe['pool']) == 1
for item in probed:
    assert item['status'] == 200 and item['valid']
    choice = item['response']['choices'][0]
    assert choice['finish_reason'] == 'stop'
    assert not choice['message'].get('reasoning') and not choice['message'].get('reasoning_content')
    assert isinstance(json.loads(choice['message']['content']), dict)
for name in ('preparation.json', 'model-manifest.json', 'acquisition-events.jsonl',
             'target-verification.json', 'token-length-preflight.json',
             'token-length-preflight.invalid-count.json', 'accepted-probe.json',
             'accepted-preflight-deployment.json', 'runtime-acceptance.json'):
    track(EVIDENCE / name)

container = json.loads(subprocess.check_output(['docker', 'inspect', 'decision-acceptance-model']))[0]
assert container['Config']['Labels']['evaluation.decision.acceptance'] == 'true'
assert container['State']['Running'] and container['Image'] == IMAGE
assert container['Config']['Entrypoint'] + container['Config']['Cmd'] == command
assert container['HostConfig']['NanoCpus'] == 8000000000
mounts = {m['Destination']: m for m in container['Mounts']}
assert mounts['/model']['Source'] == str(model_path) and not mounts['/model']['RW']
assert mounts['/service']['Source'] == str(service) and not mounts['/service']['RW']
proxy = json.loads(subprocess.check_output(['docker', 'inspect', 'decision-acceptance-proxy']))[0]
assert proxy['Config']['Labels']['evaluation.decision.acceptance'] == 'true' and proxy['State']['Running']
gpu_info = subprocess.check_output(['nvidia-smi', '--query-gpu=name,memory.total', '--format=csv,noheader'], text=True).strip().splitlines()
assert len(gpu_info) == 2 and all('A100-PCIE-40GB' in g for g in gpu_info)

old_rows = bench.read_jsonl(ROOT / 'run-001' / REFERENCE / 'responses.private.jsonl')
oldpred = {x['case_id']: x['prediction'] for x in old_rows if x['status'] == 'valid'}
old_summary = bench.local_classification_summary(inputs, labels, old_rows)
assert read(ROOT / 'run-001' / REFERENCE / 'summary.json') == dict(old_summary, model=REFERENCE)
print(json.dumps({'records_and_identity_audit_passed': True, 'paired_interval_started': True}), flush=True)
interval = bench.classification_interval(gold, {1: predicted}, {1: oldpred}, samples=2000, case_groups=groups)
transitions = Counter(('both_correct' if oldpred.get(k) == gold[k] else 'new_correct_old_wrong')
                      if predicted.get(k) == gold[k] else
                      ('old_correct_new_wrong' if oldpred.get(k) == gold[k] else 'both_wrong') for k in gold)
result = {'model': MODEL, 'run': 'run-007', 'family': 'llm', 'gpu_count': 2, 'cpu_budget': 8,
          'image_id': IMAGE, 'records': len(rows), 'correct': correct, 'failed': 2974 - len(times),
          'accuracy': recomputed['accuracy'], 'macro_f1': recomputed['macro_f1'],
          'valid_output_rate': recomputed['valid_output_rate'],
          'successful_mean_ms': recomputed['successful_task_latency']['mean_ms'],
          'successful_p99_ms': recomputed['successful_task_latency']['p99_ms']}
reference = next(x for x in prior['models'] if x['model'] == REFERENCE)
verify_prior()
assert all(sha(Path(p)) == v for p, v in artifacts.items())
track(Path(__file__))
report = {'audit_at_utc': datetime.now(timezone.utc).isoformat(), 'audit_passed': True,
          'scope': 'Supplemental offline audit; no model requests; original audit preserved',
          'model': result, 'reference': reference, 'model_revision': REVISION,
          'prior_audit_sha256': PRIOR_SHA, 'prior_artifacts_unchanged': 98,
          'total_unique_models': 15, 'total_records_including_prior': 15 * 2974,
          'records_per_model': 2974, 'distinct_inputs': 2921, 'warmup_records': 9,
          'all_input_ids_hashes_order_checked': True, 'all_record_call_mappings_checked': True,
          'warmup_inputs_and_calls_checked': True, 'protocol_and_deployment_source_hashes_match': True,
          'core_ast_equal_functions': sorted(names), 'metrics_recomputed': True,
          'predecessor_chain': ['run-001', 'run-002', 'run-003', 'run-006', 'run-007'],
          'unscored_failed_attempts': ['run-004', 'run-005'],
          'completed_at_utc': status['updated_at_utc'],
          'formal_elapsed_sum_seconds': sum(x['elapsed_ms'] for x in rows) / 1000,
          'output_token_distribution': dict(Counter(x['calls'][0]['result']['usage']['output_tokens']
                                                   for x in rows if x['status'] == 'valid')),
          'paired_transitions': dict(transitions), 'paired_95_intervals_new_minus_old': interval,
          'retained_model_service': MODEL, 'retained_container_started_at': container['State']['StartedAt'],
          'gpu_identity': gpu_info, 'artifact_sha256': artifacts,
          'limitations': ['One fixed public corpus pass; possible training exposure.',
                          'Non-thinking text-only configuration, not default thinking or multimodal capability.',
                          'Two-GPU single-in-flight latency; no concurrency or throughput comparison.',
                          'No continuous resource telemetry or long-term reliability test.',
                          'No additional full-weight SHA256; pinned manifest sizes and small-file hashes verified.',
                          'Formal records preserve parsed outputs and usage, not raw finish_reason/reasoning fields; those were checked on independent preflight outputs.',
                          'Paired cluster intervals apply only to this dataset and fixed protocol; no universal ranking.']}
output = EVIDENCE / 'classification-audit.json'
with output.open('x') as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2)
print(json.dumps({'audit_passed': True, 'model': result, 'reference': reference,
                  'paired_transitions': dict(transitions), 'interval': interval,
                  'output': str(output), 'sha256': sha(output)}), flush=True)
