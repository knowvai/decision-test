"""Preflight the explicit thinking profile, then start its single formal run."""
import ast
import asyncio
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from types import SimpleNamespace

ROOT = Path('/data/sdb/decision-model-eval/classification-20261015')
SOURCE = ROOT / 'source-r8'
EVIDENCE = ROOT / 'qwen38-thinking-20261016'
PROFILE = 'qwen3.8-27b-thinking'
IMAGE = 'sha256:c76d0e2225a4b1cb1e2109ace39639f55e714abd1a7a427acc8b0bbd7f6a83b3'
ENV = ROOT.parent / 'source-decision-v3-r3-20261012/.env'
sys.path.insert(0, str(SOURCE / 'evaluation/runner/scripts'))
sys.path.insert(0, str(SOURCE / 'deploy/docker/decision-eval'))
import public_decision_benchmark as bench
from launch_reviewed import CLASSIFICATION_PROFILES, MODELS, launch, read_key

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text())

def save(name, data):
    with (EVIDENCE / name).open('x') as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2)

def now():
    return datetime.now(timezone.utc).isoformat()

def verify_prior():
    audits = {'audit-20261015/summary.json': '4accc5327368197a99b9aa04b9c48751026b3ecfa8ad1be9b20c4b21e7e60729',
              'qwen38-supplement-20261016/classification-audit.json': '5156b7ffe6d406d5a8a34f8dcbdfbadd5e716ad8f4485274f444edf89a14dbc7'}
    counts = {}
    for name, expected in audits.items():
        assert sha(ROOT / name) == expected
        files = read(ROOT / name)['artifact_sha256']
        assert all(sha(Path(p)) == value for p, value in files.items())
        counts[name] = len(files)
    return {'audit_sha256': audits, 'artifact_counts': counts}

def command():
    return [str(ROOT / 'venv/bin/python'), '-u', str(SOURCE / 'evaluation/runner/scripts/public_decision_benchmark.py'),
        'local-classification', '--root', str(ROOT.parent), '--service-source', str(SOURCE / 'deploy/docker/decision-eval'),
        '--dataset', str(ROOT / 'dataset'), '--env-file', str(ENV), '--output', str(ROOT / 'run-008'),
        '--models', PROFILE, '--after-run', str(ROOT / 'run-007'), '--extend-roster',
        '--base-url', 'http://127.0.0.1:30889', '--port', '30889', '--timeout', '300', '--startup-timeout', '2400']

def verify_unstarted():
    assert not (ROOT / 'run-008').exists(), 'Never restart an existing formal run'
    state = subprocess.check_output(['systemctl', 'show', 'decision-classification-20261015-r8.service',
                                      '-p', 'LoadState', '--value'], text=True).strip()
    assert state == 'not-found', 'Formal unit already exists'

def prepare():
    EVIDENCE.mkdir(exist_ok=False, mode=0o700)
    prior = verify_prior()
    verify_unstarted()
    history = bench.classification_predecessor(ROOT / 'run-007', [PROFILE], extend_roster=True)
    assert len(history['roster_extension']['completed_models']) == 15
    protocol = read(ROOT / 'dataset/dataset-protocol.private.json')
    for filename, field in [('inputs.private.jsonl', 'inputs_sha256'), ('labels.private.jsonl', 'labels_sha256'),
                             ('preflight.inputs.private.jsonl', 'preflight_sha256')]:
        assert sha(ROOT / 'dataset' / filename) == protocol[field]
    unchanged = {'domain_messages', 'classification_schema', 'llm_classify', 'local_classification_summary',
                 'classification_metrics', 'classification_from_confusion', 'classification_interval', 'percentile', 'timing'}
    rel = Path('evaluation/runner/scripts/public_decision_benchmark.py')
    def nodes(path):
        return {n.name: ast.dump(n, include_attributes=False) for n in ast.parse(path.read_text()).body
                if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name in unchanged}
    assert nodes(SOURCE / rel) == nodes(ROOT / 'source-r7' / rel) and len(nodes(SOURCE / rel)) == len(unchanged)
    hashes = {str(p.relative_to(SOURCE)): sha(p) for p in SOURCE.rglob('*')
              if p.is_file() and '__pycache__' not in str(p) and '.pytest_cache' not in str(p)}
    c = json.loads(subprocess.check_output(['docker', 'inspect', 'decision-acceptance-model']))[0]
    assert c['Config']['Labels']['evaluation.decision.acceptance'] == 'true' and c['State']['Running']
    assert c['Image'] == IMAGE
    jobs = [r for r in bench.read_jsonl(ROOT / 'dataset/inputs.private.jsonl') if r['task'] == 'classification']
    synthetic = next(r for r in bench.read_jsonl(ROOT / 'dataset/preflight.inputs.private.jsonl') if r['task'] == 'classification')
    warmup = [{**synthetic, 'case_id': 'synthetic:classification:' + str(n),
               'state': {'utterance': synthetic['state']['utterance'] * n}} for n in (1, 16, 64)]
    payload = {'messages': [bench.domain_messages(j['state'], bench.DOMAIN_QUESTIONS) for j in jobs + warmup]}
    code = """import json,sys
from transformers import AutoTokenizer
data=json.load(sys.stdin)
t=AutoTokenizer.from_pretrained('/model',local_files_only=True)
lengths=[]
for messages in data['messages']:
 rendered=t.apply_chat_template(messages,tokenize=False,add_generation_prompt=True,enable_thinking=True,reasoning_effort='xhigh')
 assert rendered.endswith('<think>\\n')
 lengths.append(len(t.encode(rendered,add_special_tokens=False)))
assert max(lengths)+4096<=8192
print(json.dumps({'records':len(lengths)-3,'min_prompt_tokens':min(lengths[:-3]),'max_prompt_tokens':max(lengths[:-3]),'warmup_prompt_tokens':lengths[-3:],'output_tokens_reserved':4096,'context_limit':8192,'all_full_inputs_fit':True,'thinking_open_template_verified':True}))
"""
    result = subprocess.check_output(['docker', 'exec', '-i', 'decision-acceptance-model', 'python3', '-c', code],
                                     input=json.dumps(payload), text=True)
    tokens = json.loads(result)
    assert tokens['records'] == 2974
    save('token-length-preflight.json', tokens)
    save('preparation.json', {'at': now(), 'state': 'prepared_not_started', **prior, 'source_sha256': hashes,
        'command': command(), 'profile': CLASSIFICATION_PROFILES[PROFILE], 'prior_unique_models': 15,
        'new_unique_models': 0, 'unchanged_core_ast': sorted(unchanged), 'targeted_tests': '67 passed',
        'image_id': IMAGE, 'model_revision': '1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0',
        'token_length_preflight_sha256': sha(EVIDENCE / 'token-length-preflight.json'),
        'preflight_driver_sha256': sha(Path(__file__))})
    print(json.dumps({'prepared': True, 'token_lengths': tokens}), flush=True)

def preflight_then_start():
    os.umask(0o077)
    preparation = read(EVIDENCE / 'preparation.json')
    assert sha(Path(__file__)) == preparation['preflight_driver_sha256']
    assert all(sha(SOURCE / p) == h for p, h in preparation['source_sha256'].items())
    verify_prior()
    verify_unstarted()
    lock = (ROOT / 'classification.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    save('preflight-started.json', {'at': now(), 'pid': os.getpid(), 'synthetic_only': True})
    destination = EVIDENCE / 'preflight'
    destination.mkdir(exist_ok=False)
    launch(SimpleNamespace(root=ROOT.parent, model=PROFILE, env_file=ENV, native_port=30888,
                           public_port=30889, seqs=16, tokens=16384, enforce_eager=False))
    identity = ROOT.parent / 'acceptance-20261015/evidence' / (PROFILE + '.deployment.json')
    shutil.copyfile(identity, EVIDENCE / 'preflight-deployment.json')
    synthetic = next(r for r in bench.read_jsonl(ROOT / 'dataset/preflight.inputs.private.jsonl') if r['task'] == 'classification')
    warmup = [{**synthetic, 'case_id': 'synthetic:classification:' + str(n),
               'state': {'utterance': synthetic['state']['utterance'] * n}} for n in (1, 16, 64)]
    args = SimpleNamespace(base_url='http://127.0.0.1:30889', timeout=300, startup_timeout=2400,
                           output=destination, llm_profile=CLASSIFICATION_PROFILES[PROFILE])
    key = read_key(ENV)
    asyncio.run(bench.local_classification_model(args, 'llm', MODELS[PROFILE][2], key,
                                               [], bench.DOMAIN_QUESTIONS, warmup, destination))
    records = read(destination / 'warmup.private.json')
    assert len(records) == 9 and not (destination / 'responses.private.jsonl').read_bytes()
    checks = []
    for record in records:
        result = record['result']
        assert result['prediction'] in bench.DOMAINS
        transport = result['transport'][0]
        choice = transport['choices'][0]
        assert choice['finish_reason'] == 'stop' and choice['reasoning_chars'] > 0
        assert transport['reported_model'] == 'Qwen3.8-27B'
        assert transport['usage']['completion_tokens'] < CLASSIFICATION_PROFILES[PROFILE]['max_tokens']
        checks.append({'finish_reason': choice['finish_reason'], 'reasoning_chars': choice['reasoning_chars'],
                       'completion_tokens': transport['usage']['completion_tokens'], 'elapsed_ms': record['elapsed_ms']})
    import httpx
    with httpx.Client(trust_env=False, timeout=10) as client:
        auth = [client.get(args.base_url + '/health', headers=h).status_code for h in
                ({}, {'Authorization': 'Bearer wrong'}, {'Authorization': 'Bearer ' + key.swapcase()})]
        ready = client.get(args.base_url + '/health', headers={'Authorization': 'Bearer ' + key}).status_code
    assert auth == [401, 401, 401] and ready == 200
    verify_prior()
    assert all(sha(SOURCE / p) == h for p, h in preparation['source_sha256'].items())
    verify_unstarted()
    save('runtime-acceptance.json', {'at': now(), 'accepted': True, 'auth': auth, 'health': ready,
        'synthetic_checks': checks, 'formal_requests': 0, 'profile': CLASSIFICATION_PROFILES[PROFILE],
        'warmup_sha256': sha(destination / 'warmup.private.json'), 'prior_artifacts_unchanged': True})
    save('formal-start-intent.json', {'at': now(), 'command': preparation['command']})
    subprocess.run(['systemd-run', '--unit=decision-classification-20261015-r8',
        '--property=Restart=no', '--property=WorkingDirectory=' + str(ROOT),
        '--property=StandardOutput=append:' + str(ROOT / 'runner-r8.log'),
        '--property=StandardError=append:' + str(ROOT / 'runner-r8.log'), *preparation['command']], check=True)
    lock.close()
    print(json.dumps({'accepted': True, 'formal_unit_started': 'decision-classification-20261015-r8.service',
                      'synthetic_checks': checks}), flush=True)

if sys.argv[1] == 'prepare':
    prepare()
elif sys.argv[1] == 'preflight-then-start':
    preflight_then_start()
else:
    raise ValueError('Unknown mode')
