"""Offline audit of the frozen thinking condition; never calls model endpoints."""
import ast
import asyncio
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import statistics
import subprocess
import sys

ROOT = Path('/data/sdb/decision-model-eval/classification-20261015')
SOURCE = ROOT / 'source-r8'
EVIDENCE = ROOT / 'qwen38-thinking-20261016'
MODEL = 'qwen3.8-27b-thinking'
BASE = 'qwen3.8-27b'
IMAGE = 'sha256:c76d0e2225a4b1cb1e2109ace39639f55e714abd1a7a427acc8b0bbd7f6a83b3'
REVISION = '1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0'
PRIOR = {
    'audit-20261015/summary.json': ('4accc5327368197a99b9aa04b9c48751026b3ecfa8ad1be9b20c4b21e7e60729', 98),
    'qwen38-supplement-20261016/classification-audit.json': ('5156b7ffe6d406d5a8a34f8dcbdfbadd5e716ad8f4485274f444edf89a14dbc7', 45),
}
sys.dont_write_bytecode = True
sys.path.insert(0, str(SOURCE / 'evaluation/runner/scripts'))
sys.path.insert(0, str(SOURCE / 'deploy/docker/decision-eval'))
import httpx
import public_decision_benchmark as bench
from launch_reviewed import CLASSIFICATION_PROFILES, MODELS


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


artifacts = {}


def track(path):
    artifacts[str(path)] = sha(path)


def verify_prior():
    reports = []
    for name, (expected, count) in PRIOR.items():
        path = ROOT / name
        assert sha(path) == expected, ('prior_audit', name)
        report = read(path)
        assert len(report['artifact_sha256']) == count
        for p, value in report['artifact_sha256'].items():
            assert sha(Path(p)) == value, ('prior_artifact', p)
        reports.append(report)
    return reports


prior, nonthinking_audit = verify_prior()
assert prior['total_models'] == 14 and nonthinking_audit['total_unique_models'] == 15
preparation = read(EVIDENCE / 'preparation.json')
assert preparation['audit_sha256'] == {p: v[0] for p, v in PRIOR.items()}
assert preparation['artifact_counts'] == {p: v[1] for p, v in PRIOR.items()}
assert preparation['targeted_tests'] == '67 passed'
assert preparation['image_id'] == IMAGE and preparation['model_revision'] == REVISION
profile = {'base_model': BASE, 'enable_thinking': True, 'reasoning_effort': 'xhigh',
           'reasoning_parser': 'qwen3', 'max_tokens': 4096}
assert preparation['profile'] == CLASSIFICATION_PROFILES[MODEL] == profile
assert MODELS[MODEL] == MODELS[BASE]
for path, value in preparation['source_sha256'].items():
    assert sha(SOURCE / path) == value, ('prepared_source', path)
    track(SOURCE / path)
assert sha(EVIDENCE / 'token-length-preflight.json') == preparation['token_length_preflight_sha256']
assert sha(ROOT / 'qwen38-thinking-driver.py') == preparation['preflight_driver_sha256']
track(ROOT / 'qwen38-thinking-driver.py')
names = set(preparation['unchanged_core_ast'])
assert len(names) == 9


def functions(path):
    result = {n.name: ast.dump(n, include_attributes=False)
              for n in ast.parse(path.read_text()).body
              if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name in names}
    assert set(result) == names
    return result


runner = Path('evaluation/runner/scripts/public_decision_benchmark.py')
assert functions(SOURCE / runner) == functions(ROOT / 'source-r7' / runner)
dataset = ROOT / 'dataset'
dataset_protocol = read(dataset / 'dataset-protocol.private.json')
for name, field in [('inputs.private.jsonl', 'inputs_sha256'),
                    ('labels.private.jsonl', 'labels_sha256'),
                    ('preflight.inputs.private.jsonl', 'preflight_sha256')]:
    assert sha(dataset / name) == dataset_protocol[field]
    track(dataset / name)
track(dataset / 'dataset-protocol.private.json')
inputs = [x for x in bench.read_jsonl(dataset / 'inputs.private.jsonl') if x['task'] == 'classification']
labels = [x for x in bench.read_jsonl(dataset / 'labels.private.jsonl') if x['task'] == 'classification']
gold = {x['case_id']: x['gold'] for x in labels}
assert len(inputs) == len(labels) == len(gold) == 2974
groups = {x['case_id']: bench.digest(x['state']) for x in inputs}
assert len(set(groups.values())) == 2921
assert set(gold.values()) == set(bench.DOMAINS)
assert dataset_protocol['domain_questions'] == bench.DOMAIN_QUESTIONS
directory = ROOT / 'run-008'
protocol = read(directory / 'protocol.private.json')
status = read(directory / 'status.json')
assert status['state'] == 'complete' and status['completed'] == status['models'] == [MODEL]
assert status['active'] is None and protocol['models'] == [MODEL]
assert protocol['parent_dataset_protocol'] == bench.digest(dataset_protocol)
old_protocol = read(ROOT / 'run-007/protocol.private.json')
invariant = lambda p: {k: v for k, v in p.items() if k not in ('models', 'source_sha256', 'predecessor', 'llm')}
assert invariant(protocol) == invariant(old_protocol)
assert protocol['records'] == 2974 and protocol['concurrency'] == protocol['repeats'] == 1
assert protocol['retries'] == 0 and not protocol['fallback'] and not protocol['truncation']
assert protocol['timeout_seconds'] == 300 and not protocol['labels_sent']
assert protocol['llm'] == {
    'method': 'json_schema', 'strict': True, 'temperature': 0, 'max_tokens': 4096,
    'profile': profile,
    'transport_observer': 'hashes, usage, finish reasons and reasoning lengths; no private text'}
assert old_protocol['llm'] == {'method': 'json_schema', 'strict': True, 'temperature': 0, 'max_tokens': 64}
assert protocol['predecessor'] == bench.classification_predecessor(ROOT / 'run-007', [MODEL], extend_roster=True)
prior_models = {m['model'] for m in prior['models']} | {BASE}
assert set(protocol['predecessor']['roster_extension']['completed_models']) == prior_models
for path, value in protocol['source_sha256'].items():
    assert sha(Path(path)) == value
    track(Path(path))
packages = read(directory / 'client-packages.json')
assert all(packages[k] == v for k, v in protocol['client_packages'].items())
for name in ('protocol.private.json', 'status.json', 'client-packages.json'):
    track(directory / name)
d = directory / MODEL
for name in ('deployment.json', 'summary.json', 'responses.private.jsonl', 'warmup.private.json'):
    track(d / name)
deployment = read(d / 'deployment.json')
assert deployment['model'] == MODEL and deployment['family'] == 'llm'
assert deployment['classification_profile'] == profile
assert deployment['served_model'] == MODELS[MODEL][2] == 'Qwen3.8-27B'
assert deployment['tp'] == 2 and deployment['cpu_budget'] == 8 and deployment['image_id'] == IMAGE
assert subprocess.check_output(['docker', 'image', 'inspect', IMAGE, '--format', '{{.Id}}'], text=True).strip() == IMAGE
service = SOURCE / 'deploy/docker/decision-eval'
for path, value in deployment['source_sha256'].items():
    assert sha(service / path) == value
    track(service / path)
command = deployment['command']
for flag, value in {'--model': '/model', '--served-model-name': 'Qwen3.8-27B',
                    '--dtype': 'bfloat16', '--tensor-parallel-size': '2',
                    '--max-model-len': '8192', '--max-num-seqs': '16',
                    '--max-num-batched-tokens': '16384', '--reasoning-parser': 'qwen3'}.items():
    assert command[command.index(flag) + 1] == value
assert '--language-model-only' in command and '--no-enable-prefix-caching' in command
assert json.loads(command[command.index('--default-chat-template-kwargs') + 1]) == {
    'enable_thinking': True, 'reasoning_effort': 'xhigh'}
assert not any(x in command for x in ('--quantization', '--cpu-offload-gb', '--enable-lora'))
assert not any(k.startswith('VLLM_LORA') for k in deployment.get('env', {}))
old_deployment = read(ROOT / 'run-007' / BASE / 'deployment.json')
assert all(old_deployment[k] == deployment[k] for k in
           ('served_model', 'family', 'image_id', 'tp', 'cpu_budget', 'scheduling', 'env'))

# Reconstruct request JSON locally from the frozen LangChain binding, with HTTP forbidden.
def no_network(request):
    raise AssertionError('Offline audit must never send HTTP requests')


http = httpx.AsyncClient(transport=httpx.MockTransport(no_network))
bound = bench.local_llm_client('http://127.0.0.1:30889', 'Qwen3.8-27B',
                              'offline-audit-no-network', http, bench.DOMAIN_QUESTIONS,
                              300, profile).first.steps__['raw']
request_kwargs = {k: v for k, v in bound.kwargs.items() if k != 'ls_structured_output_format'}


def check_result(job, row):
    assert row['prediction'] in bench.DOMAINS
    assert len(row['calls']) == len(row['transport']) == 1
    call, transport = row['calls'][0], row['transport'][0]
    assert call['status'] == 'valid' and call['kind'] == 'structured_llm_classification'
    messages = bench.domain_messages(job['state'], bench.DOMAIN_QUESTIONS)
    message_hash = bench.digest({'messages': messages})
    assert call['input_sha256'] == transport['messages_sha256'] == message_hash
    payload = bound.bound._get_request_payload(messages, **request_kwargs)
    payload.update(payload.pop('extra_body', {}))
    assert bench.digest(payload) == transport['request_sha256']
    assert transport['request_options'] == {
        'model': 'Qwen3.8-27B', 'temperature': 0, 'max_completion_tokens': 4096,
        'chat_template_kwargs': {'enable_thinking': True, 'reasoning_effort': 'xhigh'}}
    assert transport['http_status'] == 200
    assert call['result']['reported_model'] == transport['reported_model'] == 'Qwen3.8-27B'
    assert call['result']['prediction'] == row['prediction']
    assert math.isfinite(call['client_elapsed_ms']) and call['client_elapsed_ms'] >= 0
    assert len(transport['choices']) == 1
    choice = transport['choices'][0]
    assert choice['finish_reason'] == 'stop'
    assert choice['reasoning_chars'] > 0 and choice['content_chars'] > 0
    for value in [transport['request_sha256'], transport['response_sha256'],
                  choice['reasoning_sha256'], choice['content_sha256']]:
        assert len(value) == 64 and all(c in '0123456789abcdef' for c in value)
    usage, raw = call['result']['usage'], transport['usage']
    assert 0 < usage['output_tokens'] == raw['completion_tokens'] <= 4096
    assert usage['input_tokens'] == raw['prompt_tokens']
    assert usage['total_tokens'] == raw['total_tokens'] == usage['input_tokens'] + usage['output_tokens']
    assert usage['total_tokens'] <= 8192
    assert 0 < raw['completion_tokens_details']['reasoning_tokens'] < raw['completion_tokens']
    assert usage['output_token_details']['reasoning'] == raw['completion_tokens_details']['reasoning_tokens']


synthetic = next(x for x in bench.read_jsonl(dataset / 'preflight.inputs.private.jsonl') if x['task'] == 'classification')
warmup_inputs = [{**synthetic, 'case_id': 'synthetic:classification:' + str(length),
                 'state': {'utterance': synthetic['state']['utterance'] * length}} for length in (1, 16, 64)] * 3
warmups = read(d / 'warmup.private.json')
assert len(warmups) == 9 and [x['input'] for x in warmups] == warmup_inputs
rows = bench.read_jsonl(d / 'responses.private.jsonl')
assert len(rows) == len({x['case_id'] for x in rows}) == 2974
assert [x['case_id'] for x in rows] == [x['case_id'] for x in inputs]
for job, row in zip(inputs, rows):
    assert row['input_sha256'] == bench.digest(job)
    assert row['task'] == 'classification' and row['repeat'] == 1
    assert row['status'] in ('valid', 'failed')
    assert math.isfinite(row['elapsed_ms']) and row['elapsed_ms'] >= 0
    if row['status'] == 'valid':
        check_result(job, row)
        assert 363 <= row['transport'][0]['usage']['prompt_tokens'] <= 403
        assert row['elapsed_ms'] >= row['calls'][0]['client_elapsed_ms']
for w, expected_tokens in zip(warmups, [363, 378, 426] * 3):
    check_result(w['input'], w['result'])
    assert w['result']['transport'][0]['usage']['prompt_tokens'] == expected_tokens
acceptance = read(EVIDENCE / 'runtime-acceptance.json')
assert acceptance['accepted'] and acceptance['health'] == 200 and acceptance['auth'] == [401, 401, 401]
assert acceptance['formal_requests'] == 0 and acceptance['profile'] == profile
assert acceptance['warmup_sha256'] == sha(EVIDENCE / 'preflight/warmup.private.json')
assert (EVIDENCE / 'preflight/responses.private.jsonl').stat().st_size == 0
preflight_warmups = read(EVIDENCE / 'preflight/warmup.private.json')
assert [x['input'] for x in preflight_warmups] == warmup_inputs
for w in preflight_warmups:
    check_result(w['input'], w['result'])
asyncio.run(http.aclose())
length_check = read(EVIDENCE / 'token-length-preflight.json')
assert length_check == {'records': 2974, 'min_prompt_tokens': 363, 'max_prompt_tokens': 403,
                        'warmup_prompt_tokens': [363, 378, 426], 'output_tokens_reserved': 4096,
                        'context_limit': 8192, 'all_full_inputs_fit': True,
                        'thinking_open_template_verified': True}


def metrics(run, model, records):
    summary = bench.local_classification_summary(inputs, labels, records)
    assert read(ROOT / run / model / 'summary.json') == dict(summary, model=model)
    predicted = {x['case_id']: x['prediction'] for x in records if x['status'] == 'valid'}
    correct = sum(predicted.get(k) == v for k, v in gold.items())
    assert summary['accuracy'] == correct / 2974
    f1s = []
    for label in bench.DOMAINS:
        tp = sum(gold[k] == label and v == label for k, v in predicted.items())
        fp = sum(gold[k] != label and v == label for k, v in predicted.items())
        fn = sum(v == label and predicted.get(k) != label for k, v in gold.items())
        f1s.append(2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0)
    assert math.isclose(statistics.mean(f1s), summary['macro_f1'], abs_tol=1e-14)
    times = sorted(x['elapsed_ms'] for x in records if x['status'] == 'valid')
    assert summary['valid_output_rate'] == len(times) / 2974
    pos = (len(times) - 1) * .99
    p99 = times[math.floor(pos)] * (1 - pos % 1) + times[math.ceil(pos)] * (pos % 1)
    assert math.isclose(p99, summary['successful_task_latency']['p99_ms'], abs_tol=1e-10)
    assert statistics.mean(times) == summary['successful_task_latency']['mean_ms']
    return predicted, {'model': model, 'run': run, 'gpu_count': 2, 'cpu_budget': 8,
                       'records': len(records), 'correct': correct, 'failed': 2974 - len(times),
                       'accuracy': summary['accuracy'], 'macro_f1': summary['macro_f1'],
                       'valid_output_rate': summary['valid_output_rate'],
                       'successful_mean_ms': statistics.mean(times), 'successful_p99_ms': p99}


predicted, result = metrics('run-008', MODEL, rows)
old_rows = bench.read_jsonl(ROOT / 'run-007' / BASE / 'responses.private.jsonl')
oldpred, reference = metrics('run-007', BASE, old_rows)
for k in ('accuracy', 'macro_f1', 'valid_output_rate', 'successful_mean_ms', 'successful_p99_ms', 'correct'):
    assert reference[k] == nonthinking_audit['model'][k]
assert [r['case_id'] for r in old_rows] == [r['case_id'] for r in rows]
assert [r['input_sha256'] for r in old_rows] == [r['input_sha256'] for r in rows]
expected = {(m['run'], m['model']) for m in prior['models']} | {('run-007', BASE), ('run-008', MODEL)}
actual = {(p.parent.parent.name, p.parent.name) for p in ROOT.glob('run-*/*/responses.private.jsonl')}
assert len(expected) == 16 and actual == expected
assert len({BASE if m == MODEL else m for _, m in expected}) == 15
assert not any(list((ROOT / run).rglob('responses.private.jsonl')) for run in ('run-004', 'run-005'))

manifest_path = ROOT / 'qwen38-supplement-20261016/model-manifest.json'
manifest = read(manifest_path)['models'][0]
assert manifest['model'] == 'Qwen/Qwen3.8-27B' and manifest['hf_revision'] == REVISION
model_path = ROOT.parent / 'staging' / BASE
assert len(manifest['files']) == 32 and sum(x['size'] for x in manifest['files'].values()) == 55586114863
for name, metadata in manifest['files'].items():
    path = model_path / name
    assert path.stat().st_size == metadata['size']
    if name.endswith('.json'):
        read(path)
    if not name.endswith('.safetensors'):
        content = path.read_bytes()
        if metadata['lfs']:
            assert hashlib.sha256(content).hexdigest() == metadata['lfs']['sha256']
        else:
            assert hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest() == metadata['blob_id']
index = read(model_path / 'model.safetensors.index.json')
assert set(index['weight_map'].values()) == {n for n in manifest['files'] if n.endswith('.safetensors')}
assert len(set(index['weight_map'].values())) == 18
track(manifest_path)
for name in ('preparation.json', 'token-length-preflight.json', 'preflight-started.json',
             'preflight-deployment.json', 'preflight/warmup.private.json',
             'preflight/responses.private.jsonl', 'runtime-acceptance.json', 'formal-start-intent.json'):
    track(EVIDENCE / name)
container = json.loads(subprocess.check_output(['docker', 'inspect', 'decision-acceptance-model']))[0]
assert container['Config']['Labels']['evaluation.decision.acceptance'] == 'true'
assert container['State']['Running'] and container['Image'] == IMAGE
assert container['Config']['Entrypoint'] + container['Config']['Cmd'] == command
assert container['HostConfig']['NanoCpus'] == 8000000000
mounts = {m['Destination']: m for m in container['Mounts']}
assert mounts['/model']['Source'] == str(model_path) and not mounts['/model']['RW']
assert mounts['/service']['Source'] == str(service) and not mounts['/service']['RW']
proxy = json.loads(subprocess.check_output(['docker', 'inspect', 'decision-acceptance-proxy']))[0]
assert proxy['Config']['Labels']['evaluation.decision.acceptance'] == 'true' and proxy['State']['Running']
gpu_info = subprocess.check_output(['nvidia-smi', '--query-gpu=name,memory.total', '--format=csv,noheader'], text=True).strip().splitlines()
assert len(gpu_info) == 2 and all('A100-PCIE-40GB' in g for g in gpu_info)
systemd = subprocess.check_output(['systemctl', 'show', 'decision-classification-20261015-r8.service',
                                  '-p', 'ActiveState', '-p', 'MainPID', '-p', 'ExecMainStatus'], text=True)
unit_state = dict(x.split('=', 1) for x in systemd.splitlines())
assert unit_state == {'MainPID': '0', 'ExecMainStatus': '0', 'ActiveState': 'inactive'}
assert str(ROOT / 'classification.lock') not in subprocess.check_output(['lslocks', '-n', '-o', 'PID,PATH'], text=True)
track(ROOT / 'runner-r8.log')
print(json.dumps({'records_and_identity_audit_passed': True, 'paired_interval_started': True}), flush=True)
interval = bench.classification_interval(gold, {1: predicted}, {1: oldpred}, samples=2000, case_groups=groups)
assert interval['independent_cases'] == 2921 and interval['source_cases'] == 2974
transitions = Counter(('both_correct' if oldpred.get(k) == gold[k] else 'thinking_correct_nonthinking_wrong')
                      if predicted.get(k) == gold[k] else
                      ('nonthinking_correct_thinking_wrong' if oldpred.get(k) == gold[k] else 'both_wrong') for k in gold)


def distribution(values):
    return {'count': len(values), 'total': sum(values), 'min': min(values),
            'mean': statistics.mean(values), 'p50': bench.percentile(values, .5),
            'p99': bench.percentile(values, .99), 'max': max(values)}


valid_rows = [x for x in rows if x['status'] == 'valid']
choices = [c for r in rows for t in r.get('transport', []) for c in t.get('choices', [])]
failures = Counter(r.get('error_type', 'unknown') for r in rows if r['status'] != 'valid')
tokens = {
    'thinking_total_output': distribution([x['transport'][0]['usage']['completion_tokens'] for x in valid_rows]),
    'thinking_reasoning': distribution([x['transport'][0]['usage']['completion_tokens_details']['reasoning_tokens'] for x in valid_rows]),
    'thinking_nonreasoning_output': distribution([x['transport'][0]['usage']['completion_tokens'] - x['transport'][0]['usage']['completion_tokens_details']['reasoning_tokens'] for x in valid_rows]),
    'nonthinking_total_output': distribution([x['calls'][0]['result']['usage']['output_tokens'] for x in old_rows if x['status'] == 'valid']),
}
counts = {'failed': len(rows) - len(valid_rows), 'length_finish': sum(c['finish_reason'] == 'length' for c in choices),
          'timeout': sum(n for name, n in failures.items() if 'timeout' in name.lower()),
          'empty_reasoning': sum(c['reasoning_chars'] == 0 for c in choices),
          'missing_transport': sum(not x.get('transport') for x in rows),
          'output_budget_reached': sum(t['usage']['completion_tokens'] >= 4096 for r in rows for t in r.get('transport', [])),
          'finish_reasons': dict(Counter(c['finish_reason'] for c in choices)), 'failure_types': dict(failures)}
verify_prior()
assert all(sha(Path(p)) == v for p, v in artifacts.items())
track(Path(__file__))
report = {
    'audit_at_utc': datetime.now(timezone.utc).isoformat(), 'audit_passed': True,
    'scope': 'Offline thinking/non-thinking configuration comparison; no model requests; prior audits preserved',
    'model': result, 'reference': reference, 'model_revision': REVISION, 'image_id': IMAGE,
    'profile': profile, 'prior_audits': {p: {'sha256': v[0], 'artifacts_unchanged': v[1]} for p, v in PRIOR.items()},
    'prior_artifact_sets_may_overlap': True, 'total_unique_models': 15, 'total_configurations': 16,
    'total_records_including_prior': 16 * 2974, 'records_per_configuration': 2974, 'distinct_inputs': 2921,
    'warmup_records': 9, 'preflight_synthetic_records': 9, 'preflight_formal_records': 0,
    'all_input_ids_hashes_order_checked': True, 'all_record_call_mappings_checked': True,
    'all_valid_request_json_hashes_reconstructed_offline': True,
    'warmup_inputs_and_calls_checked': True, 'protocol_and_deployment_source_hashes_match': True,
    'core_ast_equal_functions': sorted(names), 'metrics_recomputed': True,
    'predecessor_chain': ['run-001', 'run-002', 'run-003', 'run-006', 'run-007', 'run-008'],
    'unscored_failed_attempts': ['run-004', 'run-005'], 'completed_at_utc': status['updated_at_utc'],
    'formal_elapsed_sum_seconds': sum(x['elapsed_ms'] for x in rows) / 1000,
    'failure_and_reasoning_counts': counts, 'output_tokens': tokens,
    'mean_latency_ratio_thinking_over_nonthinking': result['successful_mean_ms'] / reference['successful_mean_ms'],
    'mean_output_token_ratio_thinking_over_nonthinking': tokens['thinking_total_output']['mean'] / tokens['nonthinking_total_output']['mean'],
    'paired_transitions': dict(transitions), 'paired_95_intervals_thinking_minus_nonthinking': interval,
    'retained_model_service': MODEL, 'retained_container_started_at': container['State']['StartedAt'],
    'gpu_identity': gpu_info, 'systemd_completion': unit_state, 'artifact_sha256': artifacts,
    'limitations': [
        'One fixed public corpus pass; possible training exposure; not a universal capability ranking.',
        'Same model with two configurations, not sixteen independent models.',
        'Thinking uses xhigh/4096 total output versus non-thinking/64; temperature zero in both, not vendor sampling defaults.',
        'Two-GPU single-in-flight full-request latency; no concurrency throughput or continuous resource telemetry.',
        'Thinking latency includes metadata observation; raw reasoning and response text are not retained, so their hashes cannot be recomputed independently.',
        'Reasoning token breakdown is provider-reported; nonreasoning tokens can include protocol delimiters.',
        'No additional full-weight SHA256; pinned manifest sizes and official small-file hashes verified.',
        'Paired cluster bootstrap measures this fixed dataset protocol only; repeated-run or deployment variance is not measured.',
    ],
}
output = EVIDENCE / 'classification-audit.json'
with output.open('x') as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2)
print(json.dumps({k: report[k] for k in ('audit_passed', 'model', 'reference', 'failure_and_reasoning_counts',
                                      'output_tokens', 'paired_transitions', 'paired_95_intervals_thinking_minus_nonthinking',
                                      'mean_latency_ratio_thinking_over_nonthinking',
                                      'mean_output_token_ratio_thinking_over_nonthinking')}), flush=True)
print(json.dumps({'output': str(output), 'sha256': sha(output)}), flush=True)
