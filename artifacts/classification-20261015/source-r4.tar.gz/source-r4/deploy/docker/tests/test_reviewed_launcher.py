"""Protect the evaluation credential when rendering the native proxy config."""

from pathlib import Path
import stat
import sys
import tempfile
import unittest

SOURCE = Path(__file__).parents[1] / "decision-eval"
sys.path.insert(0, str(SOURCE))
from launch_reviewed import write_proxy_config


class ProxyConfigTests(unittest.TestCase):
    def test_key_match_is_case_sensitive_and_config_is_private(self):
        with tempfile.TemporaryDirectory() as directory:
            key = "A1" * 16
            path = write_proxy_config(SOURCE, Path(directory), key, 30888, 30889)
            self.assertIn('"~^Bearer ' + key + '$" 1;', path.read_text())
            self.assertNotIn("${", path.read_text())
            self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)

    def test_rejects_regex_or_config_metacharacters_in_key(self):
        with tempfile.TemporaryDirectory() as directory:
            for key in ("A1" * 16 + ".*", "A1" * 16 + '"', "A1" * 16 + "\n"):
                with self.subTest(key=key), self.assertRaises(ValueError):
                    write_proxy_config(SOURCE, Path(directory), key, 30888, 30889)
            self.assertFalse((Path(directory) / ".nginx.conf").exists())


if __name__ == "__main__":
    unittest.main()
