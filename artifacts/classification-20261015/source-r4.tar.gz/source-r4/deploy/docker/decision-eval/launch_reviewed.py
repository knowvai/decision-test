"""Launch one isolated, reviewed evaluation runtime; never changes business services."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess


RUNTIME = "decision-eval-runtime:readiness-20261015"
VLLM = "decision-eval-vllm:v0.31.0-pinned"
JEV_VLLM = "decision-eval-vllm:jev-pageable-lora-20261015"
SGLANG = "decision-eval-sglang:clef-strict-length-v1"
LABEL = "evaluation.decision.acceptance"
MODELS = {
    **{name: ("worker", "models/" + name, name) for name in ("d3-edge", "d3-mini", "d3-flash")},
    **{"vela-2.0-" + size: ("worker", "staging/vela-2.0-" + size, "Vela-2.0-" + size.upper())
       for size in ("0.3b", "0.8b", "4b", "9b")},
    "jeva-4b": ("sdk", "staging/jeva-4b", "Jeva-4B"),
    "intern-4b": ("sdk", "models/intern-4b", "Intern-Decision-4B"),
    "laya-multilingual": ("laya", "models/laya-multilingual", "laya-multilingual"),
    "neohorse-jev-4b": ("neohorse", "staging/neohorse-jev-4b", "NeoHorse-Jev-4B"),
    "clef-flash": ("sglang", "models/clef-flash", "clef-flash"),
    "pplx-decider-v1.1-27b": ("sglang", "staging/pplx-decider-v1.1-27b", "pplx-decider-v1.1-27b"),
    "jev-27b": ("jev", "staging/jev-27b", "autotrust/JEV-27B"),
    "qwen3-reranker-8b": ("reranker", "models/qwen3-reranker-8b", "Qwen3-Reranker-8B"),
    "qwen3-30b-a3b-instruct-2507": ("llm", "staging/qwen3-30b-a3b-instruct-2507", "Qwen3-30B-A3B-Instruct-2507"),
}


def docker(*args):
    return subprocess.check_output(["docker", *map(str, args)], text=True).strip()


def read_key(path):
    for line in path.read_text().splitlines():
        name, sep, value = line.partition("=")
        if sep and name.strip() == "DECISION_EVAL_API_KEY":
            value = value.strip().strip("\"'")
            if re.fullmatch(r"[A-Za-z0-9_-]{32,256}", value):
                return value
    raise ValueError("Missing or invalid independent evaluation key")


def remove_owned(name):
    result = subprocess.run(["docker", "inspect", name], capture_output=True, text=True)
    if result.returncode:
        return
    container = json.loads(result.stdout)[0]
    if container["Config"].get("Labels", {}).get(LABEL) != "true":
        raise RuntimeError("Refusing to replace an unowned container")
    if container["State"]["Running"]:
        docker("stop", "--time", 30, name)
    docker("rm", name)


def write_proxy_config(source, work, key, native_port, public_port):
    if not re.fullmatch(r"[A-Za-z0-9_-]{32,256}", key):
        raise ValueError("Invalid evaluation key")
    conf = (source / "nginx.native.conf.template").read_text()
    for name, value in {"DECISION_EVAL_API_KEY": key, "EVAL_PUBLIC_PORT": public_port,
                        "EVAL_NATIVE_PORT": native_port}.items():
        conf = conf.replace("${" + name + "}", str(value))
    path = work / ".nginx.conf"
    path.write_text(conf)
    path.chmod(0o600)
    return path


def launch(args):
    os.umask(0o077)
    root = args.root.resolve(strict=True)
    work = root / "acceptance-20261015"
    work.mkdir(exist_ok=True)
    source = Path(__file__).resolve().parent
    family, relative_path, model_name = MODELS[args.model]
    if args.enforce_eager and family not in {"jev", "llm", "reranker"}:
        raise ValueError("Eager diagnostic override is only supported for these vLLM paths")
    model = (root / relative_path).resolve(strict=True)
    key = read_key(args.env_file)
    port = args.native_port
    for name in ("decision-acceptance-proxy", "decision-acceptance-head", "decision-acceptance-model"):
        remove_owned(name)
    for used_port in (port, port - 1, args.public_port):
        with socket.socket() as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(("0.0.0.0", used_port))
    active = subprocess.check_output(["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"], text=True).strip()
    if active:
        raise RuntimeError("GPU has other compute processes; stop only authorized evaluation services first")
    cache = work / "runtime" / args.model
    cache.mkdir(parents=True, exist_ok=True)
    env = {
        "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "HF_HOME": "/runtime/hf",
        "HOME": "/runtime", "OMP_NUM_THREADS": "2", "TRITON_CACHE_DIR": "/runtime/triton",
        "XDG_CACHE_HOME": "/runtime/cache", "TORCHINDUCTOR_CACHE_DIR": "/runtime/inductor",
        "SGLANG_CACHE_DIR": "/runtime/sglang", "SGLANG_JIT_CACHE_DIR": "/runtime/sglang/jit",
        "VLLM_CACHE_ROOT": "/runtime/vllm", "VLLM_NO_USAGE_STATS": "1",
        "VLLM_ENABLE_CUDA_COMPATIBILITY": "1", "DECISION_EVAL_API_KEY": key,
        "MODEL_NAME": model_name, "MODEL_PATH": "/model", "GPU_MEMORY_FRACTION": "0.90",
        "MAX_INPUT_TOKENS": "8192", "MAX_INFLIGHT_REQUESTS": "1",
        "SYSTEMONE_QUEUE_SINGLE_REQUESTS": "1", "SYSTEMONE_QUEUE_SIZE": "256",
        "SYSTEMONE_BATCH_SIZE": "1", "SYSTEMONE_TIMEOUT_SECONDS": "300",
    }
    image, tp = RUNTIME, 1
    command = []
    base_vllm = ["--model", "/model", "--served-model-name", model_name, "--dtype", "bfloat16",
                 "--host", "127.0.0.1", "--port", str(port), "--max-model-len", "8192",
                 "--max-num-seqs", str(args.seqs), "--max-num-batched-tokens", str(args.tokens),
                 "--gpu-memory-utilization", "0.90", "--no-enable-prefix-caching",
                 "--safetensors-load-strategy", "prefetch", "--safetensors-prefetch-num-threads", "2"]
    # This pinned JEV/LoRA deployment returned NaN with compiled execution.
    # Its accepted profile keeps native vLLM batching but uses eager execution.
    if args.enforce_eager or family == "jev":
        base_vllm.append("--enforce-eager")
    if family == "worker":
        command = ["vllm-srun", "serve", "/model", "--device", "cuda:0", "--served-model-name", model_name,
                   "--host", "127.0.0.1", "--port", str(port), "--dtype", "auto", "--offline",
                   "--threads", "2", "--max-num-seqs", str(args.seqs),
                   "--max-num-batched-tokens", str(args.tokens), "--max-queue", "256",
                   "--result-cache-entries", "0", "--no-enable-shared-context", "--load-attempts", "1"]
    elif family == "sdk":
        env["MODEL_BACKEND"] = "jeva" if args.model == "jeva-4b" else "intern"
        command = ["python", "-m", "uvicorn", "server:app", "--host", "127.0.0.1", "--port", str(port),
                   "--workers", "1", "--no-access-log", "--limit-concurrency", "512"]
    elif family == "laya":
        env.update(LAYA_DEVICE="cuda", LAYA_MODELS=model_name,
                   LAYA_EXTRA_MODELS=json.dumps({model_name: "/model"}), LAYA_DEFAULT_MODEL=model_name,
                   LAYA_API_KEY=key, LAYA_MAX_TOKEN_BUDGET="8192", LAYA_THREADS="2")
        command = ["python", "-m", "uvicorn", "laya_http:create_app", "--factory",
                   "--host", "127.0.0.1", "--port", str(port), "--no-access-log"]
    elif family == "neohorse":
        image = VLLM
        command = ["python3", "/model/infer/vllm/launch.py", "--bundle", "/model", "--port", str(port - 1)]
    elif family == "sglang":
        image = SGLANG
        tp = 2 if args.model.startswith("pplx-") else 1
        env["LD_LIBRARY_PATH"] = "/usr/local/cuda/compat:/usr/local/nvidia/lib:/usr/local/nvidia/lib64:/usr/local/cuda/lib64"
        command = ["python3", "-m", "sglang.launch_server", "--model-path", "/model",
                   "--served-model-name", model_name, "--dtype", "bfloat16", "--tp-size", str(tp),
                   "--context-length", "8192", "--max-running-requests", str(args.seqs),
                   "--max-prefill-tokens", str(args.tokens), "--mem-fraction-static", "0.85",
                   "--weight-loader-prefetch-checkpoints", "--weight-loader-prefetch-num-threads", "2",
                   "--host", "127.0.0.1", "--port", str(port), "--log-level", "warning"]
    else:
        image = VLLM
        tp = 1 if family == "reranker" else 2
        env["VLLM_API_KEY"] = key
        if family == "jev":
            image = JEV_VLLM
            command = ["python3", "/model/serve_decide.py", *base_vllm,
                       "--tensor-parallel-size", "2", "--enable-lora", "--max-lora-rank", "32",
                       "--lora-modules", "jev-decision=/model/adapter_vllm", "--logprobs-mode", "processed_logprobs"]
            # This appliance corrupts some pinned host-to-device LoRA transfers.
            # Only adapter loading changes; model execution remains on the GPUs.
            env.update(JEV_DECIDE_THINKING="off", JEV_DECIDE_STRATEGY="single",
                       VLLM_LORA_DISABLE_PIN_MEMORY="1")
        else:
            command = ["python3", "-m", "vllm.entrypoints.openai.api_server", *base_vllm,
                       "--tensor-parallel-size", str(tp)]
            if family == "reranker":
                command += ["--runner", "pooling", "--hf-overrides", json.dumps({
                    "architectures": ["Qwen3ForSequenceClassification"], "classifier_from_token": ["no", "yes"],
                    "is_original_qwen3_reranker": True}), "--chat-template", "/service/qwen3_reranker.jinja"]
    env_path = work / ".runtime.env"
    env_path.write_text("".join(f"{k}={v}\n" for k, v in env.items()))
    image_id = docker("image", "inspect", image, "--format", "{{.Id}}")
    runtime_user = docker("image", "inspect", image, "--format", "{{.Config.User}}")
    if runtime_user == "10001:10001":
        os.chown(cache, 10001, 10001)
    common = ["--network", "host", "--label", LABEL + "=true", "--memory", "96g", "--shm-size", "8g",
              "--read-only", "--tmpfs", "/tmp:size=4g,mode=1777", "--cap-drop", "ALL",
              "--security-opt", "no-new-privileges:true", "--env-file", env_path,
              "-v", str(model) + ":/model:ro", "-v", str(cache) + ":/runtime",
              "-v", str(source) + ":/service:ro"]
    docker("run", "-d", "--name", "decision-acceptance-model", "--gpus", "all" if tp == 2 else "device=0",
           "--cpus", "6" if family == "neohorse" else "8", *common, "--entrypoint", command[0], image_id, *command[1:])
    if family == "neohorse":
        docker("run", "-d", "--name", "decision-acceptance-head", "--cpus", "2", *common,
               "-e", "MODEL_BACKEND=neohorse", "-e", f"NEOHORSE_POOLING_URL=http://127.0.0.1:{port - 1}",
               "-e", "SYSTEMONE_BATCH_SIZE=8", "--entrypoint", "python", RUNTIME,
               "-m", "uvicorn", "server:app", "--host", "127.0.0.1", "--port", str(port),
               "--no-access-log", "--limit-concurrency", "512")
    config_path = write_proxy_config(source, work, key, port, args.public_port)
    docker("run", "-d", "--name", "decision-acceptance-proxy", "--network", "host",
           "--label", LABEL + "=true", "--read-only", "--tmpfs", "/tmp",
           "-v", str(config_path) + ":/etc/nginx/nginx.conf:ro", "--entrypoint", "nginx", "nginx:1.27-alpine",
           "-g", "daemon off;")
    scheduling = {"max_sequences": args.seqs, "max_batched_tokens": args.tokens}
    if family == "neohorse":
        scheduling = {"max_sequences": 128, "max_batched_tokens": 32768,
                      "source": "author launch.py", "adapter_max_records": 8}
    elif family == "sdk":
        scheduling = {"max_sequences": 1, "max_batched_tokens": None,
                      "cross_request_batching": False, "queue_size": 256}
    elif family == "laya":
        scheduling = {"max_sequences": None, "max_batched_tokens": None,
                      "source": "native batch request batch_size and token budget"}
    record = {"model": args.model, "served_model": model_name, "family": family, "image_id": image_id,
              "at": datetime.now(timezone.utc).isoformat(),
              "tp": tp, "cpu_budget": 8, "command": command, "scheduling": scheduling,
              "env": {k:v for k,v in env.items() if "KEY" not in k}, "native_port": port, "public_port": args.public_port}
    if family == "neohorse":
        record["head_image_id"] = docker("image", "inspect", RUNTIME, "--format", "{{.Id}}")
    record["source_sha256"] = {name: hashlib.sha256((source / name).read_bytes()).hexdigest()
                               for name in ("launch_reviewed.py", "server.py", "neohorse_backend.py", "jeva_backend.py",
                                            "laya_http.py", "deployment_probe.py", "nginx.native.conf.template")}
    if family == "jev":
        record["source_sha256"]["patch_vllm_lora.py"] = hashlib.sha256(
            (source / "patch_vllm_lora.py").read_bytes()).hexdigest()
    evidence = work / "evidence"
    evidence.mkdir(exist_ok=True)
    (evidence / (args.model + ".deployment.json")).write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({"model": args.model, "family": family, "image_id": image_id, "tp": tp}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", choices=MODELS)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--env-file", type=Path, required=True)
    parser.add_argument("--native-port", type=int, default=30888)
    parser.add_argument("--public-port", type=int, default=30889)
    parser.add_argument("--seqs", type=int, default=16)
    parser.add_argument("--tokens", type=int, default=16384)
    parser.add_argument("--enforce-eager", action="store_true", help="Explicit vLLM numerical diagnostic; recorded separately")
    launch(parser.parse_args())
