"""Opt out of pinned CPU LoRA buffers in the pinned evaluation runtime."""

import hashlib
import importlib.util
from pathlib import Path


SOURCE_SHA256 = {
    "lora_model.py": "57d0c10b374a29e2b4fda826dfd9657712394c97ddf6a8099783f718ae2860a4",
    "lora_weights.py": "767c82ea9d3a302f14046af43c638d41389a6b5136b02b08ead6ab9128b9191c",
}
IMPORT = "from vllm.utils.torch_utils import PIN_MEMORY"
OLD = 'pin_memory = str(device) == "cpu" and PIN_MEMORY'
NEW = (OLD + '\n        pin_memory = pin_memory and '
       '_lora_transfer_environ.get("VLLM_LORA_DISABLE_PIN_MEMORY", "0") != "1"')


def patch(source, filename):
    assert hashlib.sha256(source.encode()).hexdigest() == SOURCE_SHA256[filename], \
        "Unexpected vLLM LoRA loader revision"
    assert source.count(OLD) == source.count(IMPORT) == 1
    result = source.replace(IMPORT, "from os import environ as _lora_transfer_environ\n" + IMPORT)
    result = result.replace(OLD, NEW)
    compile(result, filename, "exec")
    return result


if __name__ == "__main__":
    package = Path(next(iter(importlib.util.find_spec("vllm").submodule_search_locations)))
    patched = {package / "lora" / name: patch((package / "lora" / name).read_text(), name)
               for name in SOURCE_SHA256}
    for target, source in patched.items():
        target.write_text(source)
    print("Opt-in pageable LoRA loading installed; forward and scoring unchanged.")
