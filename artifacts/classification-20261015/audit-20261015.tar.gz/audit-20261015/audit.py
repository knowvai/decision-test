"""Offline classification audit. No inference, service mutation, or private text output."""
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import statistics
import subprocess
import sys

ROOT = Path('/data/sdb/decision-model-eval/classification-20261015')
SOURCE = ROOT / 'source-r6'
sys.path.insert(0, str(SOURCE / 'evaluation/runner/scripts'))
sys.path.insert(0, str(SOURCE / 'deploy/docker/decision-eval'))
import public_decision_benchmark as bench
from deployment_probe import native_choice_request, native_choice_result
from launch_reviewed import MODELS

RUNS = {
    'run-001': ['qwen3-30b-a3b-instruct-2507'],
    'run-002': ['laya-multilingual', 'vela-2.0-0.3b', 'd3-edge',
                'vela-2.0-0.8b', 'd3-mini', 'vela-2.0-4b'],
    'run-003': ['neohorse-jev-4b', 'jeva-4b', 'd3-flash', 'clef-flash', 'vela-2.0-9b'],
    'run-006': ['jev-27b', 'pplx-decider-v1.1-27b'],
}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())
artifacts = {}


def track(path):
    artifacts[str(path)] = sha(path)


def function_identity(path):
    names = {'domain_messages', 'llm_classify', 'classification_schema',
             'local_llm_client', 'local_classification_records', 'local_classification_model',
             'local_classification_summary', 'classification_metrics',
             'classification_from_confusion', 'classification_interval', 'percentile', 'timing'}
    nodes = {n.name: ast.dump(n, include_attributes=False) for n in ast.parse(path.read_text()).body
             if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name in names}
    assert set(nodes) == names
    return nodes


dataset = ROOT / 'dataset'
dataset_protocol = read(dataset / 'dataset-protocol.private.json')
for filename, field in [('inputs.private.jsonl', 'inputs_sha256'),
                        ('labels.private.jsonl', 'labels_sha256'),
                        ('preflight.inputs.private.jsonl', 'preflight_sha256')]:
    assert sha(dataset / filename) == dataset_protocol[field]
    track(dataset / filename)
track(dataset / 'dataset-protocol.private.json')
inputs = [x for x in bench.read_jsonl(dataset / 'inputs.private.jsonl') if x['task'] == 'classification']
labels = [x for x in bench.read_jsonl(dataset / 'labels.private.jsonl') if x['task'] == 'classification']
gold = {x['case_id']: x['gold'] for x in labels}
assert len(inputs) == len(gold) == 2974
assert len({bench.digest(x['state']) for x in inputs}) == 2921
assert set(gold.values()) == set(bench.DOMAINS)
assert dataset_protocol['domain_questions'] == bench.DOMAIN_QUESTIONS
synthetic = next(x for x in bench.read_jsonl(dataset / 'preflight.inputs.private.jsonl')
                 if x['task'] == 'classification')
warmup_inputs = [{**synthetic, 'case_id': 'synthetic:classification:' + str(length),
                 'state': {'utterance': synthetic['state']['utterance'] * length}}
                for length in (1, 16, 64)] * 3
protocols, results, predictions, function_baseline = {}, [], {}, None
baseline_protocol = None
for run, models in RUNS.items():
    directory = ROOT / run
    protocol = read(directory / 'protocol.private.json')
    status = read(directory / 'status.json')
    assert status['completed'] == models
    assert protocol['parent_dataset_protocol'] == bench.digest(dataset_protocol)
    assert protocol['inputs_sha256'] == dataset_protocol['inputs_sha256']
    assert protocol['labels_sha256'] == dataset_protocol['labels_sha256']
    invariant = {k: v for k, v in protocol.items() if k not in ('models', 'source_sha256', 'predecessor')}
    if baseline_protocol is None:
        baseline_protocol = invariant
    assert invariant == baseline_protocol
    assert protocol['concurrency'] == protocol['repeats'] == 1
    assert protocol['retries'] == 0 and not protocol['fallback'] and not protocol['truncation']
    assert protocol['timeout_seconds'] == 300 and not protocol['labels_sent']
    assert protocol['records'] == 2974
    for path, expected in protocol['source_sha256'].items():
        assert sha(Path(path)) == expected, ('protocol_source', run, path)
        track(Path(path))
    runner = next(Path(p) for p in protocol['source_sha256'] if p.endswith('public_decision_benchmark.py'))
    service = next(Path(p).parent for p in protocol['source_sha256'] if p.endswith('deployment_probe.py'))
    functions = function_identity(runner)
    if function_baseline is None:
        function_baseline = functions
    assert functions == function_baseline, ('inference_or_scoring_changed', run)
    package_record = read(directory / 'client-packages.json')
    assert all(package_record[k] == v for k, v in protocol['client_packages'].items())
    predecessor = protocol.get('predecessor')
    if predecessor:
        prior_run = Path(predecessor['directory']).name
        assert predecessor['protocol_sha256'] == bench.digest(protocols[prior_run])
        assert predecessor['completed'] == RUNS[prior_run]
        if run in ('run-003', 'run-006'):
            pending = ROOT / prior_run / models[0]
            assert predecessor['unstarted_recovery']['formal_attempts'] == 0
            assert not (pending / 'responses.private.jsonl').exists()
            assert not (pending / 'summary.json').exists()
    protocols[run] = protocol
    for file in ('protocol.private.json', 'status.json', 'client-packages.json'):
        track(directory / file)
    for model in models:
        d = directory / model
        for filename in ('deployment.json', 'summary.json', 'responses.private.jsonl', 'warmup.private.json'):
            assert (d / filename).is_file()
            track(d / filename)
        deployment = read(d / 'deployment.json')
        assert deployment['model'] == model
        family, _, served = MODELS[model]
        assert (deployment['family'], deployment['served_model']) == (family, served)
        assert deployment['tp'] == (2 if family == 'llm' or model in ('jev-27b', 'pplx-decider-v1.1-27b') else 1)
        assert deployment['cpu_budget'] == 8
        for file, expected in deployment['source_sha256'].items():
            assert sha(service / file) == expected, ('deployment_source', model, file)
            track(service / file)
        image = subprocess.check_output(['docker', 'image', 'inspect', deployment['image_id'],
                                         '--format', '{{.Id}}'], text=True).strip()
        assert image == deployment['image_id']
        if model == 'jev-27b':
            assert image == 'sha256:cb363e7cc02ef8115e3afd5d068e1fbaab57711860e0ec8f555792bef567ab30'
            assert deployment['env']['VLLM_LORA_VERIFY_TRANSFER'] == '1'
        if model == 'jeva-4b':
            assert deployment['scheduling']['cross_request_batching'] is False
        warmups = read(d / 'warmup.private.json')
        assert len(warmups) == 9
        assert [x['input'] for x in warmups] == warmup_inputs
        rows = bench.read_jsonl(d / 'responses.private.jsonl')
        assert len(rows) == 2974 and len({x['case_id'] for x in rows}) == 2974
        assert [x['case_id'] for x in rows] == [x['case_id'] for x in inputs]
        for job, row in zip(inputs, rows):
            assert row['input_sha256'] == bench.digest(job)
            assert row['task'] == 'classification' and row['repeat'] == 1
            assert row['status'] in ('valid', 'failed')
            assert math.isfinite(row['elapsed_ms']) and row['elapsed_ms'] >= 0
        for job, row in [(x['input'], x['result']) for x in warmups] + list(zip(inputs, rows)):
            if row.get('status') == 'failed':
                continue
            assert row['prediction'] in bench.DOMAINS
            if family == 'llm':
                calls = row['calls']
                assert len(calls) == 1 and calls[0]['status'] == 'valid'
                assert calls[0]['input_sha256'] == bench.digest({'messages': bench.domain_messages(job['state'], bench.DOMAIN_QUESTIONS)})
                assert calls[0]['result']['reported_model'] == served
                assert calls[0]['result']['prediction'] == row['prediction']
            else:
                payload = {'model': served, 'state': job['state'], 'questions': bench.DOMAIN_QUESTIONS}
                _, request = native_choice_request(family, payload)
                assert row['request_sha256'] == bench.digest(request)
                prediction, probabilities = native_choice_result(family, payload, row['native_response'])
                assert prediction == row['prediction'] and probabilities == row['probabilities']
        recomputed = bench.local_classification_summary(inputs, labels, rows)
        stored = read(d / 'summary.json')
        assert stored == dict(recomputed, model=model), ('summary_mismatch', model)
        predicted = {x['case_id']: x['prediction'] for x in rows if x['status'] == 'valid'}
        correct = sum(predicted.get(k) == v for k, v in gold.items())
        assert recomputed['accuracy'] == correct / 2974
        f1s = []
        for label in bench.DOMAINS:
            tp = sum(gold[k] == label and v == label for k, v in predicted.items())
            fp = sum(gold[k] != label and v == label for k, v in predicted.items())
            fn = sum(v == label and predicted.get(k) != label for k, v in gold.items())
            f1s.append(2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0)
        assert math.isclose(statistics.mean(f1s), recomputed['macro_f1'], abs_tol=1e-14)
        times = sorted(x['elapsed_ms'] for x in rows if x['status'] == 'valid')
        if times:
            position = (len(times) - 1) * .99
            p99 = times[math.floor(position)] * (1 - position % 1) + times[math.ceil(position)] * (position % 1)
            assert math.isclose(p99, recomputed['successful_task_latency']['p99_ms'], abs_tol=1e-10)
            assert statistics.mean(times) == recomputed['successful_task_latency']['mean_ms']
        predictions[model] = {1: predicted}
        results.append({'model': model, 'run': run, 'gpu_count': deployment['tp'],
                        'family': family, 'serial_reference': model == 'jeva-4b',
                        'image_id': image, 'records': len(rows), 'correct': correct,
                        'failed': len(rows) - len(times),
                        'accuracy': recomputed['accuracy'], 'macro_f1': recomputed['macro_f1'],
                        'valid_output_rate': recomputed['valid_output_rate'],
                        'successful_mean_ms': recomputed['successful_task_latency']['mean_ms'],
                        'successful_p99_ms': recomputed['successful_task_latency']['p99_ms']})
        print(json.dumps({'audited': model, 'records': len(rows)}), flush=True)

assert len(results) == len(predictions) == 14
expected = {(run, model) for run, models in RUNS.items() for model in models}
actual = {(p.parent.parent.name, p.parent.name) for p in ROOT.glob('run-*/*/responses.private.jsonl')}
assert actual == expected, 'Unexpected formal attempts'
prior = read(ROOT / 'jev-repair-20261015/prior-results.sha256.json')
assert all(sha(ROOT / k) == v for k, v in prior.items())
recovery = read(ROOT / 'jev-repair-20261015/run-006-recovery.json')
for attempt in recovery['unscored_failed_attempts']:
    path = ROOT / attempt['run']
    assert sha(path / 'protocol.private.json') == attempt['protocol_sha256']
    assert not list(path.rglob('responses.private.jsonl')) and not list(path.rglob('summary.json'))
assert read(ROOT / 'run-006/status.json')['state'] == 'complete'
container = json.loads(subprocess.check_output(['docker', 'inspect', 'decision-acceptance-model']))[0]
assert container['Config']['Labels']['evaluation.decision.acceptance'] == 'true'
assert container['State']['Running'] and container['Image'] == results[-1]['image_id']

groups = {x['case_id']: bench.digest(x['state']) for x in inputs}
reference = 'qwen3-30b-a3b-instruct-2507'
intervals = {}
for model in predictions:
    if model == reference:
        continue
    intervals[model] = bench.classification_interval(gold, predictions[model], predictions[reference],
                                                     samples=2000, case_groups=groups)
    print(json.dumps({'paired_interval_done': model}), flush=True)
report = {'audit_at_utc': datetime.now(timezone.utc).isoformat(), 'scope': 'offline records/protocol/source/deployment/metric audit',
          'models': results, 'total_models': 14, 'total_records': sum(x['records'] for x in results),
          'distinct_inputs': 2921, 'records_per_model': 2974, 'predecessor_chain': list(RUNS),
          'unscored_failed_attempts': ['run-004', 'run-005'], 'prior_artifacts_unchanged': len(prior),
          'inference_timing_scoring_ast_equal': True, 'all_input_ids_hashes_order_checked': True,
          'all_warmups_native_output_and_request_mapping_checked': True,
          'protocol_and_deployment_source_hashes_match': True, 'metrics_recomputed': True,
          'final_service_retained': 'pplx-decider-v1.1-27b', 'reference': reference,
          'paired_95_intervals': intervals, 'paired_multiple_comparisons_adjusted': False,
          'artifact_sha256': artifacts,
          'limitations': ['One fixed public corpus pass; possible training exposure.',
                          'No concurrency/load test or long-term reliability claim.',
                          'Deployment GPU/CPU budgets verified, but no continuous resource telemetry or historical peak-memory reconstruction.',
                          'No fresh full-weight rehash; existing pinned acquisition identity retained.',
                          'JEV uses an appliance-specific loading workaround; underlying driver/allocator cause remains unproven.',
                          'Paired intervals are versus Qwen only, unadjusted for multiple comparisons; no universal model ranking.']}
output = ROOT / 'audit-20261015/summary.json'
with output.open('x') as f:
    json.dump(report, f, indent=2, ensure_ascii=False)
print(json.dumps({'audit_passed': True, 'models': results, 'output': str(output)}), flush=True)
