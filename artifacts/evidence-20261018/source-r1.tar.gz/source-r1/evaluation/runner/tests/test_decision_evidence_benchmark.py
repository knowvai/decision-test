"""Grade provenance, binary semantics and reuse guards; never invokes models."""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parents[1] / "scripts"))
sys.path.insert(0, str(Path(__file__).parents[3] / "deploy/docker/decision-eval"))
import decision_evidence_benchmark as e
import decision_capacity_preflight as capacity


def fixture(grades, cid="case"):
    candidates = [{"fragment_id": str(i), "content": "document " + str(i),
                   "content_sha256": hashlib.sha256(("document " + str(i)).encode()).hexdigest()}
                  for i in range(len(grades))]
    pool = {"case_id": cid, "query": "question " + cid,
            "query_identity_sha256": e.query_key("question " + cid), "candidates": candidates}
    label = {"case_id": cid, "grades": dict(zip((c["fragment_id"] for c in candidates), grades)),
             "positive_ids": [str(i) for i, g in enumerate(grades) if g >= 2]}
    return pool, label


def records(pool, chosen):
    return [{"case_id": pool["case_id"], "fragment_id": c["fragment_id"], "status": "valid",
             "prediction": "relevant" if i in chosen else "irrelevant"}
            for i, c in enumerate(pool["candidates"])]


class EvidenceTests(unittest.TestCase):
    def test_independent_original_source_join_and_corruption_checks(self):
        script = Path(__file__).parents[3] / "docs/research/2026-10-18-evidence-audit.py"
        spec = importlib.util.spec_from_file_location("evidence_offline_audit", script)
        audit = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(audit)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source, dataset = root / "source", root / "dataset"
            source.mkdir()
            dataset.mkdir()
            (source / "queries.dev.tsv").write_text("qid\ttext\n1\tquestion\n")
            (source / "qrels.dev.tsv").write_text("qid\t-\tpid\trel\n1\t0\ta\t1\n1\t0\tb\t2\n")
            (source / "collection.tsv").write_text("pid\ttext\na\ttopic only\nb\tanswer evidence\n")
            pp = {"case_id": "t2q:1", "source_qid": "1", "query": "question", "candidates": [
                {"fragment_id": "t2p:a", "source_pid": "a", "content": "topic only"},
                {"fragment_id": "t2p:b", "source_pid": "b", "content": "answer evidence"}]}
            ll = {"case_id": "t2q:1", "grades": {"t2p:a": 1, "t2p:b": 2}, "positive_ids": ["t2p:b"]}
            e.p.save(dataset / "protocol.json", {"split_qids": {"formal": ["1"]},
                "source_sha256": {f.name: e.sha(f) for f in source.iterdir()}})
            inputs, labels = dataset / "formal.inputs.private.jsonl", dataset / "formal.labels.private.jsonl"
            e.p.save_rows(inputs, [pp])
            e.p.save_rows(labels, [ll])
            self.assertTrue(audit.verify_original_sources(dataset, source)["passed"])
            bad = {**ll, "positive_ids": ["t2p:a", "t2p:b"]}
            labels.write_text(json.dumps(bad) + "\n")
            with self.assertRaises(AssertionError):
                audit.verify_original_sources(dataset, source)
            labels.write_text(json.dumps(ll) + "\n")
            pp["candidates"][1]["content"] = "shortened"
            inputs.write_text(json.dumps(pp) + "\n")
            with self.assertRaises(AssertionError):
                audit.verify_original_sources(dataset, source)

    def test_grades_are_not_old_binary_relevance(self):
        pool, label = fixture([0, 1, 2, 3])
        e.validate([pool], [label])
        self.assertEqual(label["positive_ids"], ["2", "3"])
        wrong = {**label, "positive_ids": ["1", "2", "3"]}
        with self.assertRaises(AssertionError):
            e.validate([pool], [wrong])

    def test_complete_content_hash_and_no_unjudged_candidates(self):
        pool, label = fixture([0, 2])
        for mutation in ("content", "unjudged", "grade"):
            pp, ll = deepcopy(pool), deepcopy(label)
            if mutation == "content":
                pp["candidates"][0]["content"] += " truncated"
            elif mutation == "unjudged":
                del ll["grades"]["0"]
            else:
                ll["grades"]["0"] = -1
            with self.assertRaises(AssertionError):
                e.validate([pp], [ll])

    def test_negative_only_pool_is_valid_and_scored_separately(self):
        pool, label = fixture([0, 1])
        e.validate([pool], [label])
        out = e.quality([pool], [label], records(pool, set()))
        self.assertEqual(out["correct_empty_rate"]["point"], 1)
        self.assertIsNone(out["positive_pool_macro"]["f1"])
        self.assertEqual(out["candidate_accuracy"], 1)
        out = e.quality([pool], [label], records(pool, {1}))
        self.assertEqual(out["correct_empty_rate"]["point"], 0)
        self.assertEqual(out["counts"]["fp"], 1)

    def test_empty_predictions_on_evidence_pool_are_misses(self):
        pool, label = fixture([0, 1, 2, 3])
        out = e.quality([pool], [label], records(pool, set()))
        self.assertEqual(out["positive_pool_macro"]["f1"]["point"], 0)
        self.assertEqual(out["missed_all_evidence_rate"]["point"], 1)
        self.assertEqual(out["counts"]["fn"], 2)
        self.assertIsNone(out["correct_empty_rate"])

    def test_all_keep_is_not_perfect_quality(self):
        pool, label = fixture([0, 1, 2, 3])
        out = e.quality([pool], [label], records(pool, {0, 1, 2, 3}))
        self.assertEqual(out["positive_pool_macro"]["precision"]["point"], .5)
        self.assertEqual(out["positive_pool_macro"]["recall"]["point"], 1)
        self.assertEqual(out["grades"]["1"]["accepted"], 1)
        self.assertEqual(out["character_reduction"], 0)

    def test_missing_or_failed_requests_do_not_receive_negative_credit(self):
        pool, label = fixture([0, 1, 2, 3])
        rows = records(pool, {2})[:3]
        rows[0]["status"] = "failed"
        out = e.quality([pool], [label], rows)
        self.assertEqual(out["counts"]["planned"], 4)
        self.assertEqual(out["counts"]["unscored"], 2)
        self.assertEqual(out["counts"]["fn"], 1)
        self.assertEqual(out["candidate_accuracy"], .5)
        self.assertEqual(out["valid_pools"], 0)
        self.assertEqual(out["positive_pool_macro"]["f1"]["point"], 0)
        self.assertEqual(out["grades"]["3"]["unscored"], 1)
        self.assertIsNone(out["character_reduction"])

    def test_duplicate_or_extra_requests_rejected(self):
        pool, label = fixture([2])
        rows = records(pool, {0})
        with self.assertRaises(AssertionError):
            e.quality([pool], [label], rows + rows)
        with self.assertRaises(AssertionError):
            e.quality([pool], [label], [{**rows[0], "fragment_id": "unknown"}])

    def test_independent_deterministic_selection_includes_no_evidence(self):
        qs = {str(i): "query " + str(i) for i in range(30)}
        rs = {q: {"p": 0 if int(q) % 2 else 2} for q in qs}
        qs["29"] = qs["28"]
        selected, _ = e.select_queries(qs, rs, {e.query_key(qs["0"])},
                                      {"engineering": 2, "validation": 2, "formal": 5, "no_evidence": 3})
        keys = [e.query_key(qs[q]) for ids in selected.values() for q in ids]
        self.assertEqual(len(keys), len(set(keys)))
        self.assertNotIn(e.query_key(qs["0"]), keys)
        self.assertTrue(all(rs[q]["p"] == 0 for q in selected["no_evidence"]))
        again, _ = e.select_queries(qs, rs, {e.query_key(qs["0"])},
                                   {"engineering": 2, "validation": 2, "formal": 5, "no_evidence": 3})
        self.assertEqual(selected, again)

    def test_modes_use_identical_rubric_without_noul_criteria(self):
        choice, noul = e.questions("choice"), e.questions("noul")
        self.assertEqual(choice["relevance"]["instructions"], noul["relevance"]["instructions"])
        self.assertNotIn("criteria", noul["relevance"])
        self.assertEqual(sum(len(e.modes(m)) for m in e.p.ROSTER), 28)

    def test_original_adapters_keep_default_contract(self):
        state = {"query": "q", "document": "d"}
        original = deepcopy(e.p.QUESTIONS)
        base = capacity.llm_body("Qwen3.8-27B", state)
        self.assertIn(original["relevance"]["instructions"], base["messages"][0]["content"])
        _, evidence = e.p.refine_wire("llm", "Qwen3.8-27B", state, e.questions("choice"))
        self.assertIn(e.INSTRUCTIONS, evidence["messages"][0]["content"])
        for key in ("temperature", "max_tokens", "response_format", "chat_template_kwargs"):
            self.assertEqual(evidence[key], base[key])
        self.assertEqual(e.p.QUESTIONS, original)
        _, native = e.p.refine_wire("worker", "model", state)
        self.assertEqual(native["questions"]["relevance"]["instructions"], original["relevance"]["instructions"])
        self.assertTrue(native["questions"]["relevance"]["require_full_input"])

    def test_decode_preserves_native_choice_even_if_probability_disagrees(self):
        raw = {"answers": {"relevance": {"type": "choice", "choice": "irrelevant",
               "probabilities": {"relevant": .8, "irrelevant": .2}}}}
        out = e.decode("sdk", "model", {}, raw, "choice")
        self.assertEqual(out["prediction"], "irrelevant")
        replay = e.decode("sdk", "model", {}, out["native_response"], "choice")
        for key in ("prediction", "probabilities", "native_response"):
            self.assertEqual(replay[key], out[key])

    def test_noul_fixed_readout_and_strict_llm(self):
        raw = {"answers": {"relevance": {"type": "noul", "noul": .5}}}
        self.assertEqual(e.decode("sdk", "model", {}, raw, "noul")["prediction"], "irrelevant")
        raw = {"model": "model", "choices": [{"finish_reason": "stop", "message": {"content": '{"choice":"relevant"}'}}]}
        out = e.decode("llm", "model", {}, raw, "choice")
        self.assertEqual(out["prediction"], "relevant")
        raw["choices"][0]["message"]["reasoning_content"] = "unexpected"
        with self.assertRaises(AssertionError):
            e.decode("llm", "model", {}, raw, "choice")

    def test_modes_alternate_by_pool_without_phase_overlap(self):
        pools = [fixture([0, 2], str(i))[0] for i in range(2)]
        seq = list(e.sequence("d3-mini", {"engineering": (pools, []), "formal": (pools, [])}))
        self.assertEqual([m for _, _, m in seq], ["choice", "noul", "noul", "choice"] * 2)
        self.assertEqual([phase for phase, _, _ in seq], ["engineering"] * 4 + ["formal"] * 4)

    def test_audit_checks_decodes_hashes_and_real_pool_walls(self):
        from launch_reviewed import MODELS
        model = "d3-edge"
        family, _, served = MODELS[model]
        pool, label = fixture([0, 2])
        data = {"formal": ([pool], [label])}
        rows, chains = [], []
        for phase, pp, mode in e.sequence(model, data):
            start = len(rows) * 2
            for c in pp["candidates"]:
                identity = {"model": model, "phase": phase, "arm": mode, "stage": "refine",
                            "case_id": pp["case_id"], "fragment_id": c["fragment_id"]}
                state = e.p.pair_state(pp, c)
                path, body = e.p.refine_wire(family, served, state, e.questions(mode))
                answer = ({"type": "choice", "choice": "relevant", "probabilities": {"relevant": .8, "irrelevant": .2}}
                          if mode == "choice" else {"type": "noul", "noul": .8})
                parsed = e.decode(family, served, state, {"answers": {"relevance": answer}}, mode)
                t = len(rows) * 2
                rows.append({**identity, **parsed, "status": "valid", "http_status": 200, "calls": 1,
                    "inflight_at_start": 1, "call_id": e.b.digest(identity), "input_sha256": e.b.digest(state),
                    "request_sha256": e.b.digest(body), "path": path, "started_seconds": t + .1,
                    "http_started_seconds": t + .2, "ended_seconds": t + 1,
                    "elapsed_ms": 800, "intent_journal_ms": 100})
            end = len(rows) * 2 - .1
            chains.append({"phase": phase, "arm": mode, "case_id": pp["case_id"], "valid": True,
                "calls": 2, "started_seconds": start, "ended_seconds": end,
                "wall_ms": 1000 * (end - start), "selected_ids": [c["fragment_id"] for c in pp["candidates"]]})
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            e.p.save_rows(folder / "requests.jsonl", rows)
            e.p.save_rows(folder / "intents.jsonl", rows)
            e.p.save_rows(folder / "chains.jsonl", chains)
            for name in ("deployment", "container", "auth"):
                e.p.save(folder / (name + ".json"), {})
            result = e.audit_model(folder, model, data)
            self.assertEqual(result["calls"], 4)
            self.assertTrue(result["passed"])
            bad = deepcopy(rows)
            bad[0]["prediction"] = "irrelevant"
            with patch.object(e.b, "read_jsonl", side_effect=[bad, rows, chains]):
                with self.assertRaises(AssertionError):
                    e.audit_model(folder, model, data)
            bad_chains = deepcopy(chains)
            bad_chains[0]["wall_ms"] = sum(r["elapsed_ms"] for r in rows[:2])
            with patch.object(e.b, "read_jsonl", side_effect=[rows, rows, bad_chains]):
                with self.assertRaises(AssertionError):
                    e.audit_model(folder, model, data)


if __name__ == "__main__":
    unittest.main()
