# Answer Evidence Selection Benchmark

## Authorization And Baseline

The owner clarified that the product task is answer-evidence selection and on
2026-10-18 authorized rethinking the method and rerunning the comparison. This is
an independent evaluation, not a correction to historical measurements or a
production change. Baseline repository HEAD is
`37070e98d32ff92ef153095a42b8fdf746bd1c0e`, with existing uncommitted evaluation
files. Preserve all old classification, capacity, passage, noul and diagnosis
artifacts and frozen sources. No production Agent behavior changes.

First divergent stage: the previous C-MTEB binary labels include grade-1
relevance and the prompt asks for retrieval relevance, whereas the owner needs
information that can contribute to an answer. The old quality scores therefore
do not answer the product question. Runtime/protocol evidence remains valid.

New flow: pinned original queries + complete collection + graded qrels ->
deterministic independent query splits -> full-candidate native binary decisions
-> immutable requests and measured pool walls -> independent offline audit.
The existing serial transport, readiness checks, launcher, native mapping,
nonthinking LLM parser, timing and bootstrap helpers remain authoritative.

## Labels And Data

- Use original `THUIR/T2Ranking` revision
  `2a369a430a70979223f1b9a41b1919774d46b432`, not guessed grades from C-MTEB lists.
- Positive = original grade 2 or 3; negative = grade 0 or 1. Preserve original
  grades and IDs in private labels. This is a public proxy for evidence utility,
  not human verification of factual truth, source reliability or generated answers.
- Verify full source SHA256 and exact qid/pid joins. No fuzzy text mapping,
  synthetic labels, treating unjudged passages as negatives or model relabeling.
- Exclude normalized queries appearing anywhere in the previous C-MTEB source,
  not just the 232 recently used pools. Deduplicate normalized query identities.
- Freeze seed `answer-evidence-v1` before model results. Hash-order the
  remaining queries into 12 engineering, 20 validation and 200 main-test pools.
  Keep every judged candidate in each selected pool and the complete text.
- Independently select 40 additional genuinely no-evidence pools from the
  remaining queries as a diagnostic set. Do not merge this oversampled set into
  representative main-test aggregates. Main-test pools can also have no evidence.
- Freeze exact counts, source hashes, split IDs and input/label hashes before any
  inference. No automatic truncation, result-based exclusions or replacements.
  An unsupported complete input is an explicit gate failure, not a silent crop.
- Do not tune prompts, thresholds or models on validation or formal outputs in
  this run. Validation reports remain separate from the new main test.

## Conditions

Compare the existing 13 Decision models in BOTH native choice and native noul,
plus the two existing nonthinking LLMs: 15 deployments, 28 conditions. Use the
unchanged roster from `decision_passage_benchmark.py`, no Intern or thinking
profiles. Modes share deployment and alternate their first position by pool.
Each mode evaluates every complete query-passage pair once. No calibrated
retention threshold, Top1 fallback, reranker, TopN sweep or formal replay.

All models receive the same evidence rubric: does this passage provide concrete
information that partially or fully meets this question's information need?
Partial answers, applicable conditions and useful counterevidence can qualify;
topic overlap alone does not. Do not require a complete standalone answer or
agreement with a potentially false premise. Treat passage text as data, not an
instruction. Retain binary schema IDs `relevant`/`irrelevant` for compatibility,
but explicitly define them as evidence yes/no in this protocol.

Choice uses the returned native category. Noul uses the returned native category
or boolean, otherwise fixed binary argmax (false on a tie), never label-fitted
thresholds. LLM uses strict JSON, temperature 0, nonthinking, 64 output tokens.

## Measurement And Safety

- Global HTTP concurrency 1, single complete pair per refinement request; no
  overlapping modes, pools, phases or deployments. No automatic inference retries.
- Existing deployment images, weights and resource budgets; startup allowance
  2400 seconds and per-HTTP hard wall limit 300 seconds. Hold the existing shared
  evaluation flock across deployment and execution. New exclusive output root.
- Only replace owned `evaluation.decision.acceptance=true` evaluation containers on
  the test host. Leave proxy reranker, proxy and business embedding unchanged.
- Any invalid response stops this sequence; timeout/5xx/ambiguous transport
  failures do not imply GPU work ended. No automatic repair, restart or resume.
- Engineering is separate from scored phases. No additional synthetic inference.
  Record cold engineering latency separately; validation/formal timing follows it.
- Actual pool wall time includes request construction, network/auth, parsing and
  request journals; excludes pool-row persistence and between-pool identity checks.
  Report measured walls, not sums of request latency. Request timing separately
  exposes journal overhead; no n=1-to-concurrency or equal-hardware claims.

## Reporting

- Main evidence-containing pools: macro Precision/Recall/F1 with paired query
  bootstrap 95% intervals, missed-all-evidence rate and complete-set exact match.
- No-evidence pools: correct-empty rate, false-accept rate and false-accepted
  candidates; show natural main-test and oversampled diagnostics separately.
- All candidates: TP/FP/FN/TN, failures/missing coverage, Accuracy, kept count and
  text-character reduction (not token savings), grade-2/3 retention and grade-0/1
  rejection. Failures remain in planned denominators; no scoring only successes.
- Compare all-keep and all-reject baselines. Empty prediction on a positive pool
  has P/R/F1 zero; empty prediction on a negative-only pool is a correct rejection,
  evaluated separately rather than a fabricated positive-class F1.
- Report request and measured-pool mean/P95/P99, valid/attempted/planned counts,
  failed/timeouts and all-attempt elapsed time. Pair mode differences on the same
  queries; do not declare tiny point differences significant or a universal winner.
- Audit source/deployment identity, exact grade joins, split isolation, every
  call/input/request hash, no retries, global nonoverlap and preservation. Keep
  raw inputs and reasoning out of console logs and public reports.
- This experiment does not generate final RAG answers, so it cannot establish
  answer correctness, production throughput or the best attainable prompt.

## Implementation Scope

New evidence-only runner and tests; optional question parameters on the existing
passage/LLM adapters with unchanged defaults; preparation/audit artifacts; this
plan, execution record and current evaluation tasks. Reuse all other mechanisms.
No change to historical remote snapshots, production routes, model weights,
classification logic, capacity measurements or service infrastructure.
