"""Offline independent verification/reporting for the answer-evidence run."""
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path
import sys


def verify_original_sources(dataset_path, source_path):
    """Independently rejoin original IDs, grades and text before runtime freezing."""
    protocol = json.loads((dataset_path / "protocol.json").read_text())
    def digest(path):
        value = hashlib.sha256()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
                value.update(chunk)
        return value.hexdigest()
    for name, expected in protocol["source_sha256"].items():
        assert digest(source_path / name) == expected, name
    csv.field_size_limit(1024 * 1024 * 1024)
    with (source_path / "queries.dev.tsv").open() as stream:
        queries = {r["qid"]: r["text"] for r in csv.DictReader(stream, delimiter="\t", quoting=csv.QUOTE_NONE)}
    graded = defaultdict(dict)
    with (source_path / "qrels.dev.tsv").open() as stream:
        for row in csv.DictReader(stream, delimiter="\t", quoting=csv.QUOTE_NONE):
            assert row["pid"] not in graded[row["qid"]]
            graded[row["qid"]][row["pid"]] = int(row["rel"])
    expected_texts, totals, all_qids = {}, {}, set()
    for phase, selected in protocol["split_qids"].items():
        pools = [json.loads(line) for line in (dataset_path / (phase + ".inputs.private.jsonl")).read_text().splitlines()]
        labels = {r["case_id"]: r for r in map(json.loads, (dataset_path / (phase + ".labels.private.jsonl")).read_text().splitlines())}
        assert [p["source_qid"] for p in pools] == selected
        grades = Counter()
        conflicts = 0
        for pool in pools:
            qid = pool["source_qid"]
            assert qid not in all_qids and pool["query"] == queries[qid]
            all_qids.add(qid)
            label = labels[pool["case_id"]]
            assert label["grades"] == {"t2p:" + pid: g for pid, g in graded[qid].items()}
            assert set(label["positive_ids"]) == {"t2p:" + pid for pid, g in graded[qid].items() if g in (2, 3)}
            assert {c["source_pid"] for c in pool["candidates"]} == set(graded[qid])
            binary_by_text = defaultdict(set)
            for candidate in pool["candidates"]:
                pid = candidate["source_pid"]
                assert candidate["fragment_id"] == "t2p:" + pid
                if pid in expected_texts:
                    assert expected_texts[pid] == candidate["content"]
                expected_texts[pid] = candidate["content"]
                grades[graded[qid][pid]] += 1
                binary_by_text[candidate["content"]].add(graded[qid][pid] >= 2)
            conflicts += sum(len(v) > 1 for v in binary_by_text.values())
        assert not conflicts, "Identical query/text has conflicting evidence labels"
        totals[phase] = {"pools": len(pools), "pairs": sum(grades.values()), "grades": dict(grades),
                         "conflicting_identical_text_labels": conflicts}
    found = set()
    with (source_path / "collection.tsv").open() as stream:
        for row in csv.DictReader(stream, delimiter="\t", quoting=csv.QUOTE_NONE):
            pid = row["pid"]
            if pid in expected_texts:
                assert pid not in found and row["text"] == expected_texts[pid]
                found.add(pid)
    assert found == set(expected_texts)
    return {"passed": True, "dataset_protocol_sha256": digest(dataset_path / "protocol.json"),
            "original_sources_sha256": protocol["source_sha256"], "unique_passage_ids": len(found),
            "source_ids_grades_and_full_text_rejoined": True, "splits": totals,
            "script_sha256": digest(Path(__file__))}


def report_md(result):
    pct = lambda v: f"{100 * v:.2f}"
    interval = lambda v: "N/A" if v is None else f"{pct(v['point'])} [{pct(v['low'])}, {pct(v['high'])}]"
    lines = ["# 答案证据筛选：原生二选一", "",
        "正例为原始 T2Ranking L2/L3，负例为 L0/L1；全部候选、完整片段，无校准阈值、无 reranker。",
        "主测试 200 个新问题；额外 40 个无证据池单列，不混入主测试。旧相关性任务成绩不可直接作提升基线。", "",
        f"实际请求 {result['calls']}；全部审计通过：{result['passed']}。原始标签/划分来源、请求哈希、原生结果读出、全局 n=1 和历史保全均已复核。", "",
        "## 主测试质量", "",
        "P/R/F1 只在有 L2/L3 的问题上作池级宏平均，含 95% 配对池级 bootstrap 区间。无证据池另报正确全拒绝率。", "",
        "| 模型 / 模式 | Precision % | Recall % | F1 % | Accuracy % | 漏光证据 % | 无证据正确全拒绝 % | 保留片段 |",
        "| --- | --- | --- | --- | --- | --- | --- | ---: |"]
    for model, value in result["models"].items():
        for mode, phase in value["phases"]["formal"].items():
            q = phase["quality"]
            m = q["positive_pool_macro"]
            lines.append(f"| {model} / {mode} | {interval(m['precision'])} | {interval(m['recall'])} | {interval(m['f1'])} | {pct(q['candidate_accuracy'])} | {interval(q['missed_all_evidence_rate'])} | {interval(q['correct_empty_rate'])} | {q['kept_candidates']} |")
    lines += ["", "## 无模型基线", "", "| 规则 | Precision % | Recall % | F1 % | 无证据正确全拒绝 % | Accuracy % |",
              "| --- | --- | --- | --- | --- | --- |"]
    for mode, q in result["baselines"]["formal"].items():
        m = q["positive_pool_macro"]
        lines.append(f"| {mode} | {interval(m['precision'])} | {interval(m['recall'])} | {interval(m['f1'])} | {interval(q['correct_empty_rate'])} | {pct(q['candidate_accuracy'])} |")
    lines += ["", "## 模式配对", "", "差值为 noul-choice；未做多重比较校正，不按微小点差宣称最优。", "",
              "| 模型 | 主测试 ΔF1 pp [95% CI] | 主测试 ΔRecall pp [95% CI] | 40 池正确全拒绝 choice / noul % |",
              "| --- | --- | --- | --- |"]
    for model, delta in result["mode_differences"].items():
        phases = result["models"][model]["phases"]
        empty = [phases["no_evidence"][m]["quality"]["correct_empty_rate"]["point"] for m in ("choice", "noul")]
        lines.append(f"| {model} | {interval(delta['formal']['f1'])} | {interval(delta['formal']['recall'])} | {pct(empty[0])} / {pct(empty[1])} |")
    lines += ["", "## 主测试耗时", "", "整池为实测 wall，包含网络/鉴权及请求落盘；排除整池记录落盘和池间身份检查。请求耗时扣除 intent 落盘、排除结果落盘；二者不是同一时钟。", "",
              "| 模型 / 模式 | 有效 / 尝试 / 计划 | 请求 mean / P95 / P99 ms | 整池 mean / P95 / P99 ms | 全尝试请求耗时 s |",
              "| --- | --- | --- | --- | ---: |"]
    for model, value in result["models"].items():
        for mode, phase in value["phases"]["formal"].items():
            rs, wall = phase["requests"], phase["pool_wall_ms"]
            latency = rs["all_attempt_latency_ms"]
            triple = lambda t: " / ".join(f"{t[k]:.2f}" for k in ("mean_ms", "p95_ms", "p99_ms"))
            lines.append(f"| {model} / {mode} | {rs['valid']} / {rs['attempted']} / {phase['quality']['counts']['planned']} | {triple(latency)} | {triple(wall)} | {rs['attempted'] * latency['mean_ms'] / 1000:.3f} |")
    lines += ["", "## 等级错误", "", "L0/L1 列为误留率，L2/L3 列为保留率，均使用对应等级全部候选为分母。", "",
              "| 模型 / 模式 | L0 误留 % | L1 误留 % | L2 保留 % | L3 保留 % | TP / FP / FN / TN |",
              "| --- | --- | --- | --- | --- | --- |"]
    for model, value in result["models"].items():
        for mode, phase in value["phases"]["formal"].items():
            q = phase["quality"]
            rates = [pct(g.get("accepted", 0) / g["planned"]) if g["planned"] else "N/A" for g in q["grades"].values()]
            confusion = " / ".join(str(q["counts"].get(k, 0)) for k in ("tp", "fp", "fn", "tn"))
            lines.append(f"| {model} / {mode} | " + " | ".join(rates) + f" | {confusion} |")
    lines += ["", "## 边界", "",
        "- 原始四级标签是答案证据价值的公开代理，不是逐条事实核验或来源可靠性标注。没有评测最终生成答案，不能声称 RAG 回答正确率提高。",
        "- 有证据池与无证据池的指标分别计算；不能把正例池的空结果当正确，也不能把负例池的正确拒绝当漏判。",
        "- 同一部署中两个 Decision 模式按池交替先后；不同模型仍顺序部署。保留原资源与镜像差异，不宣称等资源最优或由 n=1 外推并发容量。",
        "- 工程、验证、主测试、额外无证据池的完整统计、失败数、字符缩减及模式差值在 JSON；字符缩减不是 token 节省。",
        "- 没有在本轮输出上调提示、阈值或选择 TopN；所有推理记录和旧结果保留。", ""]
    return "\n".join(lines)


def main(args):
    if args.verify_data_only:
        result = verify_original_sources(args.root / "dataset-v1", args.original_source)
        with args.output.open("x") as stream:
            json.dump(result, stream, indent=2)
            stream.write("\n")
        print(json.dumps(result))
        return
    sys.path.insert(0, str(args.root / "source-r1/evaluation/runner/scripts"))
    sys.path.insert(0, str(args.root / "source-r1/deploy/docker/decision-eval"))
    import decision_evidence_benchmark as e

    def offline(event, _args):
        if event in ("socket.connect", "subprocess.Popen"):
            raise RuntimeError("Offline audit cannot issue network calls or launch processes")

    sys.addaudithook(offline)
    run = args.root / "run-001"
    data, dataset = e.load_dataset(args.root / "dataset-v1")
    protocol = json.loads((run / "protocol.json").read_text())
    frozen = json.loads((args.root / "preparation-r1/frozen.json").read_text())
    assert json.loads((run / "status.json").read_text())["stage"] == "complete"
    assert protocol["models"] == list(e.p.ROSTER) and protocol["conditions"] == 28
    assert protocol["questions"] == {m: e.questions(m) for m in ("choice", "noul")}
    assert protocol["dataset_protocol"] == dataset
    assert protocol["http_concurrency"] == 1 and protocol["retries"] == 0
    assert e.sha(args.root / "preparation-r1/frozen.json") == protocol["frozen_sha256"]
    preserved = json.loads((args.root / "preparation-r1/preservation.json").read_text())
    provenance = json.loads((args.root / "preparation-r1/data-provenance.json").read_text())
    assert provenance["passed"] and provenance["source_ids_grades_and_full_text_rejoined"]
    assert provenance["dataset_protocol_sha256"] == frozen["dataset_protocol_sha256"]
    assert e.sha(args.root / "preparation-r1/data-provenance.json") == frozen["data_provenance_sha256"]
    e.p.check_artifacts(preserved)
    e.p.check_artifacts(protocol["source_sha256"])
    assert e.sha(args.root / "dataset-v1/protocol.json") == frozen["dataset_protocol_sha256"]
    result = {"passed": True, "audited_at": e.p.now(), "models": {}, "baselines": {},
              "dataset": dataset, "data_provenance": provenance, "mode_differences": {}, "calls": 0,
              "preserved_files": len(preserved), "script_sha256": e.sha(__file__)}
    seen_calls, end = set(), 0
    for model in e.p.ROSTER:
        folder = run / model
        recorded = json.loads((folder / "audit.json").read_text())
        rebuilt = e.audit_model(folder, model, data)
        assert rebuilt == recorded, "Model audit differs: " + model
        deployment = json.loads((folder / "deployment.json").read_text())
        original = json.loads((args.baseline / model / "deployment.json").read_text())
        for key in ("model", "served_model", "family", "image_id", "tp", "cpu_budget", "host_memory_limit_gib", "command", "scheduling", "env"):
            assert deployment[key] == original[key], (model, key)
        rows = e.b.read_jsonl(folder / "requests.jsonl")
        assert rebuilt["first_started_seconds"] >= end
        end = rebuilt["last_ended_seconds"]
        for row in rows:
            assert row["call_id"] not in seen_calls
            seen_calls.add(row["call_id"])
        # Cross-check candidate confusion directly from original graded labels.
        for phase, (pools, labels) in data.items():
            truth = {(r["case_id"], fid): grade >= 2 for r in labels for fid, grade in r["grades"].items()}
            for mode in e.modes(model):
                group = [r for r in rows if r["phase"] == phase and r["arm"] == mode]
                counts = Counter()
                for row in group:
                    gold = truth[(row["case_id"], row["fragment_id"])]
                    pred = row["prediction"] == "relevant"
                    counts["tp" if gold and pred else "fn" if gold else "fp" if pred else "tn"] += 1
                quality = rebuilt["phases"][phase][mode]["quality"]
                assert sum(counts.values()) == len(truth) == quality["counts"]["planned"]
                assert all(quality["counts"].get(k, 0) == counts[k] for k in ("tp", "fp", "fn", "tn"))
        result["models"][model] = rebuilt
        result["calls"] += rebuilt["calls"]
        if len(e.modes(model)) == 2:
            result["mode_differences"][model] = {}
            chain_rows = e.b.read_jsonl(folder / "chains.jsonl")
            for phase in data:
                cs = rebuilt["phases"][phase]["choice"]["quality"]["cases"]
                ns = rebuilt["phases"][phase]["noul"]["quality"]["cases"]
                assert [c["case_id"] for c in cs] == [c["case_id"] for c in ns]
                delta = {}
                for metric in ("precision", "recall", "f1", "correct_empty", "exact_match"):
                    pairs = [(c, n) for c, n in zip(cs, ns) if
                             (bool(c["gold_count"]) if metric in ("precision", "recall", "f1") else
                              not c["gold_count"] if metric == "correct_empty" else True)]
                    delta[metric] = e.b.bootstrap_mean([n[metric] - c[metric] for c, n in pairs]) if pairs else None
                wall = {m: {r["case_id"]: r["wall_ms"] for r in chain_rows if r["phase"] == phase and r["arm"] == m and r["valid"]}
                        for m in ("choice", "noul")}
                paired = sorted(wall["choice"].keys() & wall["noul"].keys())
                delta["paired_valid_pools"] = len(paired)
                delta["noul_minus_choice_wall_ms"] = e.b.bootstrap_mean([wall["noul"][cid] - wall["choice"][cid] for cid in paired])
                delta["choice_wall_over_noul_wall_ratio"] = sum(wall["choice"][cid] for cid in paired) / sum(wall["noul"][cid] for cid in paired)
                result["mode_differences"][model][phase] = delta
    for phase, (pools, labels) in data.items():
        result["baselines"][phase] = {}
        for name, prediction in (("all_keep", "relevant"), ("all_reject", "irrelevant")):
            rows = [{"case_id": pool["case_id"], "fragment_id": c["fragment_id"], "status": "valid", "prediction": prediction}
                    for pool in pools for c in pool["candidates"]]
            result["baselines"][phase][name] = e.quality(pools, labels, rows)
    assert result["calls"] == frozen["planned_calls_total"] == len(seen_calls)
    e.p.check_artifacts(preserved)
    e.p.check_artifacts(protocol["source_sha256"])
    e.p.save(args.output, result)
    with args.output.with_suffix(".md").open("x") as stream:
        stream.write(report_md(result))
    print(json.dumps({"passed": True, "models": len(result["models"]), "conditions": 28,
                      "calls": result["calls"], "preserved_files": len(preserved)}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--baseline", type=Path)
    parser.add_argument("--verify-data-only", action="store_true")
    parser.add_argument("--original-source", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    main(parser.parse_args())
