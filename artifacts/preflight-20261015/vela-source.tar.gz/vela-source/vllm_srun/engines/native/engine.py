"""The native PyTorch engine: builds a backbone from a ``ModelSpec`` and runs it on one device."""

from __future__ import annotations

from collections.abc import Callable
from contextlib import AbstractContextManager
from dataclasses import dataclass
from functools import partial
from typing import Any, cast

import torch
from torch import nn

from ...accel import onednn
from ...accel.kernels import CONTIGUOUS
from ...plugins.base import (
    Accelerator,
    BackboneSpec,
    DeviceInfo,
    EncoderBatch,
    EncoderOutput,
    Engine,
    EngineModel,
    EngineOptions,
    ForwardBatch,
    ForwardOutput,
    ImageInputs,
    ModelSpec,
    ModuleT,
    TreeBatch,
    TreeOutput,
)
from ...scheduler.planner import padded
from . import fast, models
from .encoder import EncoderGraphs
from .models.forest import ForestShape
from .models.lora import attach
from .models.packed import Packed, packed_unavailable
from .models.qwen3_5 import noncausal_masks, rope_index
from .models.tree import Tree
from .reduced import REDUCED_AUTOCAST, linear_bytes, reduced_view, unavailable
from .weights import (
    cast_parameters,
    keep_linear_bf16,
    lay_out_linears,
    load_adapter,
    load_backbone,
)

# FLA's gated-delta kernels index q / k / v with 32-bit offsets: one forward's stay within 2**30 elements.
GATED_DELTA_ELEMENTS = 2**30 - 1


def graph_receipt(graphs: dict[str | None, EncoderGraphs]) -> dict[str, Any]:
    """The backbone's graph statistics, each branch's under ``branches``."""
    out = graphs[None].receipt()
    branches = {name: g.receipt() for name, g in graphs.items() if name is not None}
    if branches:
        out["branches"] = branches
    return out


class NativeEngineModel(EngineModel):
    spec: ModelSpec

    def __init__(
        self,
        backbone: nn.Module,
        accelerator: Accelerator,
        device_info: DeviceInfo,
        spec: ModelSpec,
        options: EngineOptions,
        residency: dict[str, int] | None,
        branches: dict[str, nn.Module] | None = None,
        reduced_kind: str | None = None,
        towers: dict[str, nn.Module] | None = None,
    ):
        """``reduced_kind`` asks for a reduced copy of every layer stack, which batches that merge requests run (``reduced.py``).

        A copy the device cannot run is skipped, and the receipt says why.
        ``towers`` are the model's other backbones (``ModelSpec.towers``).
        """
        self.backbone = backbone
        self.branches = branches or {}
        self.towers = towers or {}
        self.accelerator = accelerator
        self.device_info = device_info
        self.device = accelerator.torch_device(device_info)
        self.spec = spec
        self.options = options
        self.residency = residency
        self.reduced_kind = reduced_kind
        self.reduced_skipped = (
            None
            if reduced_kind is None
            else unavailable(reduced_kind, self.device, device_info.bf16)
        )
        # Views are taken before the linears are laid out: they copy nn.Linear layers.
        self.reduced: dict[str | None, nn.Module] = (
            {}
            if reduced_kind is None or self.reduced_skipped
            else {
                name: reduced_view(module, reduced_kind)
                for name, module in self.stacks().items()
            }
        )
        self.kernels = accelerator.kernels(device_info)
        self.kernels.allow_approximate = (
            not options.exact_kernels_only and spec.dtype.approximate_kernels
        )
        self.kernels.use_variants(spec.kernel_variants)
        self.linear = self.kernels.select("linear")
        if self.linear.variant is not None:
            for module in (backbone, *self.branches.values(), *self.towers.values()):
                lay_out_linears(module, self.linear.fn)
        # Packed linears, contiguous GeGLU, norms and unpadded attention grids
        # (``packed(uniform=True)``) compute each row the same in any batch.
        self.batch_invariant = (
            spec.encoder
            and self.device.type == "cpu"
            and self.linear.variant == onednn.PACKED
            and self.kernels.select("geglu").variant == CONTIGUOUS
        )
        for module in (
            *self.stacks().values(),
            *self.reduced.values(),
            *self.towers.values(),
        ):
            cast(models.Backbone, module).kernels = self.kernels
        self.fast: dict[str, Any] = {}
        self.masks: fast.Masks | None = None
        self.graphs: fast.Graphs | None = None
        self.encoder_graphs: dict[str | None, EncoderGraphs] = {}
        self.reduced_graphs: dict[str | None, EncoderGraphs] = {}
        self.noncausal = bool(getattr(backbone, "noncausal", False))
        # Why merged forwards cannot pack their rows here (``models/packed.py``); None when they can.
        self.packed_reason = (
            "encoders pack rows through encode"
            if spec.encoder
            else packed_unavailable(backbone, self.kernels)
        )
        if self.device.type == "cuda" and not spec.encoder:
            self._install_fast()
        if self.device.type == "cuda" and spec.encoder and options.graphs:
            self.encoder_graphs = {
                name: EncoderGraphs(cast(models.EncoderBackbone, module), self.device)
                for name, module in self.stacks().items()
            }
            self.reduced_graphs = {
                name: EncoderGraphs(cast(models.EncoderBackbone, view), self.device)
                for name, view in self.reduced.items()
            }

    def stacks(self) -> dict[str | None, nn.Module]:
        """Every layer stack by branch name; ``None`` is the backbone's own."""
        return {None: self.backbone} | self.branches

    def _install_fast(self) -> None:
        """The exact GPU fast path (``fast.py``): fused layers, lean LoRA, host masks and graphs.

        The host masks and graphs are causal, so a noncausal backbone takes only the
        fused layers and builds its masks per forward (``noncausal_masks``).
        """
        options, backbone = self.options, self.backbone
        if options.fused_kernels:
            reason = fast.fused_unavailable(backbone, self.kernels)
            self.fast["fused_layers"] = 0 if reason else fast.install_fused(backbone)
            if reason:
                self.fast["fused_skipped"] = reason
        if self.noncausal:
            return
        if self.spec.backbone.lora is not None and self.residency is not None:
            self.fast["lora"] = fast.install_lean_lora(backbone)
        if options.fused_kernels or options.graphs:
            self.masks = fast.Masks()
        if options.graphs:
            assert self.masks is not None
            self.graphs = fast.Graphs(backbone, self.masks)

    def receipt(self) -> dict[str, Any]:
        """What runs this model: kernels, fast-path pieces and graph statistics."""
        out: dict[str, Any] = {"kernels": self.kernels.describe(), **self.fast}
        if not self.spec.encoder:
            out["packed"] = (
                {"attention": self.kernels.preferred_source("varlen_attention")}
                if self.packed_reason is None
                else {"skipped": self.packed_reason}
            )
        if self.graphs is not None:
            out["graphs"] = self.graphs.receipt()
        if self.encoder_graphs:
            out["encoder_graphs"] = graph_receipt(self.encoder_graphs)
        if self.reduced:
            out["reduced"] = {
                "kind": self.reduced_kind,
                "bytes": sum(linear_bytes(view) for view in self.reduced.values()),
                **(
                    {"encoder_graphs": graph_receipt(self.reduced_graphs)}
                    if self.reduced_graphs
                    else {}
                ),
            }
        elif self.reduced_skipped:
            out["reduced"] = {
                "kind": self.reduced_kind,
                "skipped": self.reduced_skipped,
            }
        return out

    def autocast(self) -> AbstractContextManager[Any]:
        if self.device.type == "cpu":
            from contextlib import nullcontext

            return nullcontext()
        return self.accelerator.autocast(self.device_info, self.spec.dtype.autocast)

    def reduced_autocast(self) -> AbstractContextManager[Any]:
        """The reduced copy's compute dtype: BF16 autocast for BF16 copies, none otherwise."""
        dtype = REDUCED_AUTOCAST.get(self.reduced_kind or "")
        if dtype is None:
            from contextlib import nullcontext

            return nullcontext()
        if self.device.type == "cpu":
            return torch.autocast("cpu", dtype=dtype)
        return self.accelerator.autocast(self.device_info, "bfloat16")

    supports_shared_context = True

    @property
    def replays_graphs(self) -> bool:
        return self.graphs is not None

    @property
    def approximate_kernels(self) -> bool:
        return any(
            not self.kernels.select(name).exact
            for name in self.kernels.available
            if self.kernels.has(name)
        )

    def _run_tree(
        self, prefix: torch.Tensor, suffixes: list[torch.Tensor], padded_exact: bool
    ) -> torch.Tensor:
        """The prefix once and every suffix from it, packed in one row; the suffix rows ``[n, width, H]``."""
        lengths = [len(suffix) for suffix in suffixes]
        packed = torch.cat([prefix, *suffixes])[None].to(self.device)
        tree = Tree(
            len(prefix), lengths, padded(max(lengths)), self.device, padded_exact
        )
        hidden = cast(models.TreeBackbone, self.backbone).forward_tree(packed, tree)
        return tree.rows(hidden[0, len(prefix) :])

    def _forward_tree(self, batch: ForwardBatch) -> ForwardOutput:
        """The batch as one shared-context tree: its first ``shared_prefix`` tokens computed once."""
        prefix, lengths = batch.shared_prefix, batch.lengths
        ids = batch.input_ids
        gather = (batch.gather - prefix).clamp(min=0).to(self.device)
        query = (batch.query - prefix).to(self.device)
        with torch.inference_mode(), self.autocast():
            rows_hidden = self._run_tree(
                ids[0, :prefix],
                [ids[row, prefix:length] for row, length in enumerate(lengths)],
                padded_exact=any(length != padded(max(lengths)) for length in lengths),
            )
            rows = torch.arange(rows_hidden.shape[0], device=rows_hidden.device)
            gathered = rows_hidden[rows[:, None], gather]
            queried = rows_hidden[rows, query]
        return ForwardOutput(gathered=gathered, query=queried)

    def tree(self, batch: TreeBatch) -> TreeOutput:
        method = "forward_forest" if batch.layout == "rows" else "forward_tree"
        if not hasattr(self.backbone, method):
            raise NotImplementedError(
                f"the native {self.spec.backbone.model_type!r} backbone has no {batch.layout} tree forward"
            )
        width = max(len(block) for block in batch.blocks)
        with torch.inference_mode(), self.autocast():
            if batch.layout == "rows":
                return TreeOutput(hidden=self._tree_rows(batch))
            hidden = None
            for owner, prefix in enumerate(batch.prefixes):
                members = [i for i, o in enumerate(batch.owners) if o == owner]
                if not members:
                    continue
                rows = self._run_tree(
                    torch.tensor(prefix, dtype=torch.long),
                    [torch.tensor(batch.blocks[i], dtype=torch.long) for i in members],
                    padded_exact=False,
                )
                if hidden is None:
                    hidden = rows.new_zeros((len(batch.blocks), width, rows.shape[-1]))
                span = min(width, rows.shape[1])
                hidden[members, :span] = rows[:, :span]
        assert hidden is not None
        return TreeOutput(hidden=hidden)

    def _tree_rows(self, batch: TreeBatch) -> torch.Tensor:
        """``layout: rows``: left-padded prefix rows and right-padded blocks (``models/forest.py``)."""

        def padded_rows(
            sequences: list[list[int]], left: bool
        ) -> tuple[torch.Tensor, torch.Tensor]:
            width = max(len(sequence) for sequence in sequences)
            ids = torch.zeros((len(sequences), width), dtype=torch.long)
            mask = torch.zeros((len(sequences), width), dtype=torch.long)
            for row, sequence in enumerate(sequences):
                cut = (
                    slice(width - len(sequence), width)
                    if left
                    else slice(0, len(sequence))
                )
                ids[row, cut] = torch.tensor(sequence, dtype=torch.long)
                mask[row, cut] = 1
            return ids.to(self.device), mask.to(self.device)

        prefix_ids, prefix_mask = padded_rows(batch.prefixes, left=True)
        block_ids, block_mask = padded_rows(batch.blocks, left=False)
        width = prefix_ids.shape[1]
        shape = ForestShape(
            tuple(width - len(prefix) for prefix in batch.prefixes),
            tuple(len(block) for block in batch.blocks),
            tuple(batch.owners),
        )
        owner = torch.tensor(batch.owners, dtype=torch.long, device=self.device)
        backbone = cast(models.ForestBackbone, self.backbone)

        def blocks_of(
            prefix_ids: torch.Tensor,
            prefix_mask: torch.Tensor,
            block_ids: torch.Tensor,
            block_mask: torch.Tensor,
            owner: torch.Tensor,
        ) -> torch.Tensor:
            return backbone.forward_forest(
                prefix_ids, prefix_mask, block_ids, block_mask, owner, shape
            )[1]

        inputs = (prefix_ids, prefix_mask, block_ids, block_mask, owner)
        # ROCm keeps forests eager: an eager forward while a forest graph is
        # alive faults there (docs/records/cuda-vela-forest-graphs.md).
        if self.graphs is None or torch.version.hip is not None:
            return blocks_of(*inputs)
        # A replay writes the graph's one output buffer, so the caller gets a copy.
        return self.graphs.run(
            ("forest", prefix_ids.shape, block_ids.shape, shape),
            inputs,
            blocks_of,
            prefix_ids.numel() + block_ids.numel(),
        ).clone()

    @property
    def supports_packed(self) -> bool:
        return self.packed_reason is None

    def forward(self, batch: ForwardBatch) -> ForwardOutput:
        if batch.shared_prefix:
            return self._forward_tree(batch)
        if batch.packed:
            return self._forward_packed(batch)
        input_ids = batch.input_ids.to(self.device)
        attention_mask = batch.attention_mask.to(self.device)
        gather = batch.gather.to(self.device)
        query = batch.query.to(self.device)
        padded = any(n != input_ids.shape[1] for n in batch.lengths)
        with torch.inference_mode(), self.autocast():
            if batch.images is not None:
                hidden = self._forward_images(batch, input_ids, attention_mask, padded)
            elif self.graphs is not None:
                hidden = self.graphs(input_ids, attention_mask, batch.lengths)
            elif self.masks is not None:
                hidden = self.backbone(
                    input_ids,
                    attention_mask,
                    masks=self.masks.build(attention_mask, padded),
                )
            elif self.noncausal:
                full, linear = noncausal_masks(attention_mask, padded)
                hidden = self.backbone(
                    input_ids, attention_mask, masks={"full": full, "linear": linear}
                )
            else:
                hidden = self.backbone(input_ids, attention_mask)
            rows = torch.arange(hidden.shape[0], device=hidden.device)
            gathered = hidden[rows[:, None], gather]
            queried = hidden[rows, query]
        return ForwardOutput(gathered=gathered, query=queried)

    def _forward_images(
        self,
        batch: ForwardBatch,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        padded: bool,
    ) -> torch.Tensor:
        """Final hidden states of image prompts: the vision tower's features in place of the placeholders.

        The rotary positions come from the batch's host-side token IDs, so the
        forward never reads the device back.
        """
        positions, image_features = self._media(
            batch, batch.input_ids.cpu(), batch.attention_mask.cpu()
        )
        images = cast(ImageInputs, batch.images)
        videos = images.videos
        hidden: torch.Tensor = cast(Any, self.backbone).forward_images(
            input_ids,
            attention_mask,
            image_features,
            images.token_id,
            positions,
            padded,
            videos=(
                (videos.features.to(self.device), videos.token_id)
                if videos is not None
                else None
            ),
        )
        return hidden

    def _media(
        self, batch: ForwardBatch, input_ids: torch.Tensor, attention_mask: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Rotary positions ``[3, B, L]`` of padded host rows with image placeholders, and the image features.

        The rotary positions come from the batch's host-side token IDs, so the
        forward never reads the device back.
        """
        images = cast(ImageInputs, batch.images)
        tower = self.towers.get(images.tower)
        if tower is None or not hasattr(self.backbone, "forward_images"):
            raise ValueError(f"the {self.spec.name} backbone reads no images")
        merge = cast(Any, tower).merge
        videos = images.videos
        inputs = [("image", images.token_id, images.grids)]
        if videos is not None:
            inputs.append(("video", videos.token_id, videos.grids))
        for kind, token_id, grids in inputs:
            placeholders = int((batch.input_ids == token_id).sum())
            features = sum(t * h * w for t, h, w in grids) // merge**2
            if placeholders != features:
                raise ValueError(
                    f"{placeholders} {kind} tokens but {features} {kind} features"
                )
        positions = rope_index(
            input_ids,
            attention_mask,
            images.grids,
            images.token_id,
            merge,
            video_grids=videos.grids if videos is not None else None,
            video_token_id=videos.token_id if videos is not None else None,
        ).to(self.device)
        if images.features is not None:
            image_features = images.features.to(self.device)
        elif images.pixel_values is not None:
            image_features = tower(images.pixel_values.to(self.device), images.grids)
        else:
            raise ValueError("image inputs need pixel values or features")
        return positions, image_features

    def _forward_packed(self, batch: ForwardBatch) -> ForwardOutput:
        """Rows back to back in one row (``ForwardBatch.packed``, ``models/packed.py``).

        Image rows take the rotary positions each row has alone (``rope_index``
        over the rows left-padded on the host), laid out as the packed row.
        """
        if self.packed_reason is not None:
            raise ValueError(f"packed forwards are unavailable: {self.packed_reason}")
        if sum(batch.lengths) != batch.input_ids.shape[-1]:
            raise ValueError("packed lengths do not cover the input IDs")
        layout = Packed(batch.lengths, self.device)
        input_ids = batch.input_ids.to(self.device)
        backbone = cast(Any, self.backbone)
        with torch.inference_mode(), self.autocast():
            if batch.images is None:
                hidden = backbone.forward_packed(input_ids, layout)
            else:
                host = batch.input_ids.reshape(-1).cpu()
                width = layout.max_length
                rows = torch.zeros((layout.rows, width), dtype=host.dtype)
                mask = torch.zeros((layout.rows, width), dtype=torch.long)
                for row, (start, end) in enumerate(
                    zip(
                        layout.cu_seqlens_cpu[:-1].tolist(),
                        layout.cu_seqlens_cpu[1:].tolist(),
                        strict=True,
                    )
                ):
                    rows[row, width - (end - start) :] = host[start:end]
                    mask[row, width - (end - start) :] = 1
                positions, image_features = self._media(batch, rows, mask)
                positions = positions[:, mask.to(positions.device).bool()][:, None]
                videos = batch.images.videos
                hidden = backbone.forward_images_packed(
                    input_ids,
                    layout,
                    image_features,
                    batch.images.token_id,
                    positions,
                    videos=(
                        (videos.features.to(self.device), videos.token_id)
                        if videos is not None
                        else None
                    ),
                )
            flat = hidden[0]
            gathered = flat[batch.gather.to(self.device)]
            queried = flat[batch.query.to(self.device)]
        return ForwardOutput(gathered=gathered, query=queried)

    def tower_features(
        self,
        name: str,
        pixel_values: torch.Tensor,
        grids: list[tuple[int, int, int]],
        packed: bool = False,
    ) -> torch.Tensor:
        tower = self.towers.get(name)
        if tower is None:
            raise ValueError(f"the {self.spec.name} model has no {name} tower")
        with torch.inference_mode(), self.autocast():
            if packed and self.packed_reason is None:
                features: torch.Tensor = tower(
                    pixel_values.to(self.device), grids, packed=True
                )
            else:
                features = tower(pixel_values.to(self.device), grids)
        return features

    def encode(self, batch: EncoderBatch) -> EncoderOutput:
        """Hidden states at the batch's exits, through its branch if it names one.

        Packed rows stay packed and padded rows padded. A reduced batch runs its
        stack's reduced copy when one is loaded, and every stack has its graphs.
        A batch that names a tower runs it on its named inputs.
        """
        if batch.tower is not None:
            return self._encode_tower(batch)
        stack = self.backbone if batch.branch is None else self.branches[batch.branch]
        if not hasattr(stack, "encode"):
            return self._encode_decoder(batch)
        reduced = batch.reduced and batch.branch in self.reduced
        if reduced:
            stack = self.reduced[batch.branch]
        backbone = cast(models.EncoderBackbone, stack)
        graphs = (self.reduced_graphs if reduced else self.encoder_graphs).get(
            batch.branch
        )
        context = self.reduced_autocast if reduced else self.autocast
        exits = tuple(batch.layers) or (backbone.num_layers,)
        if batch.lengths is not None:
            if sum(batch.lengths) != batch.input_ids.numel():
                raise ValueError("packed lengths do not cover the input IDs")
            if graphs is not None:
                with torch.inference_mode(), context():
                    hidden = graphs(
                        batch.input_ids, batch.lengths, exits, batch.normalize_exits
                    )
                return EncoderOutput(hidden=hidden)
            input_ids = batch.input_ids.to(self.device)
            layout = backbone.packed(
                batch.lengths, self.device, uniform=self.batch_invariant
            )
        else:
            input_ids = batch.input_ids.to(self.device)
            rows, width = input_ids.shape
            layout = backbone.padded(batch.attention_mask, rows, width, self.device)
        with torch.inference_mode(), context():
            hidden = backbone.encode(input_ids, layout, exits, batch.normalize_exits)
        return EncoderOutput(hidden=hidden)

    def _encode_tower(self, batch: EncoderBatch) -> EncoderOutput:
        """One tower's named outputs (all of them unless ``batch.outputs`` names some)."""
        assert batch.tower is not None
        tower = self.towers.get(batch.tower)
        if tower is None:
            raise ValueError(
                f"no tower {batch.tower!r} is loaded; loaded: {sorted(self.towers)}"
            )
        inputs = {
            name: value.to(self.device) for name, value in batch.graph_inputs.items()
        }
        with torch.inference_mode(), self.autocast():
            outputs = tower(**inputs)
        if batch.outputs:
            outputs = {name: outputs[name] for name in batch.outputs}
        return EncoderOutput(outputs=outputs)

    def _encode_decoder(self, batch: EncoderBatch) -> EncoderOutput:
        """A decoder's last layer (embedders such as Qwen3-Embedding): right-padded causal rows.

        Causal attention never reads a later position, so padding changes no
        real token; packed requests come back packed.
        """
        last = len(cast(nn.ModuleList, self.backbone.layers))
        if set(batch.layers) - {last}:
            raise ValueError(f"a decoder backbone serves its last layer ({last}) only")
        if batch.lengths is not None:
            width = max(batch.lengths)
            mask = torch.arange(width)[None, :] < torch.tensor(batch.lengths)[:, None]
            input_ids = torch.zeros(mask.shape, dtype=torch.long)
            input_ids[mask] = batch.input_ids.cpu()
        else:
            assert batch.attention_mask is not None
            input_ids, mask = batch.input_ids, batch.attention_mask.bool()
        with torch.inference_mode(), self.autocast():
            hidden = self.backbone(
                input_ids.to(self.device), mask.to(self.device, torch.long)
            )
        if batch.lengths is not None:
            hidden = hidden[mask.to(hidden.device)]
        return EncoderOutput(hidden={last: hidden})

    def _modules(self) -> tuple[nn.Module, ...]:
        return (self.backbone, *self.branches.values(), *self.towers.values())

    def _parameters(self) -> list[nn.Parameter]:
        """Every parameter once (branches share the backbone's embedding)."""
        unique = {
            id(parameter): parameter
            for module in self._modules()
            for parameter in module.parameters()
        }
        return list(unique.values())

    def _packed(self) -> list[onednn.PackedLinear]:
        return [
            layer
            for module in self._modules()
            for layer in module.modules()
            if isinstance(layer, onednn.PackedLinear)
        ]

    def max_forward_tokens(self) -> int | None:
        """Tokens one GPU forward may hold before a gated-delta q / k / v outgrows FLA's offsets."""
        config = self.spec.backbone.config
        heads = config.get("linear_num_value_heads")
        if self.device.type == "cpu" or not heads:
            return None
        width: int = heads * max(
            config["linear_key_head_dim"], config["linear_value_head_dim"]
        )
        return GATED_DELTA_ELEMENTS // width

    def parameter_count(self) -> int:
        packed = sum(layer.weight_elements for layer in self._packed())
        return packed + sum(parameter.numel() for parameter in self._parameters())

    def memory_bytes(self) -> int:
        copy_bytes = sum(linear_bytes(view) for view in self.reduced.values())
        packed = sum(
            layer.packed.numel() * layer.packed.element_size()
            for layer in self._packed()
        )
        return (
            copy_bytes
            + packed
            + sum(p.numel() * p.element_size() for p in self._parameters())
        )

    def place(self, module: ModuleT) -> ModuleT:
        """A head on this device, its linear layers laid out like the backbone's."""
        module = module.to(self.device)
        if self.linear.variant is not None:
            lay_out_linears(module, self.linear.fn)
        return module

    def close(self) -> None:
        self.backbone = None  # type: ignore[assignment]  # close() releases the backbone; a closed model runs nothing
        self.branches = {}
        self.towers = {}
        self.reduced = {}
        self.encoder_graphs = {}
        self.reduced_graphs = {}
        if self.device.type == "cuda":
            torch.cuda.empty_cache()


@dataclass
class HostStacks:
    """A backbone, its branches and towers loaded in host memory, in the dtypes the device holds them in."""

    backbone: nn.Module
    branches: dict[str, nn.Module]
    towers: dict[str, nn.Module]
    residency: dict[str, int] | None


class NativeEngine(Engine):
    name = "native"
    auto_priority = 0
    dtypes = ("auto", "float32", "bfloat16", "float16")

    @classmethod
    def descriptor(cls) -> dict[str, Any]:
        return {
            **super().descriptor(),
            "architectures": sorted(models.ARCHITECTURES),
            "outputs": ["gathered", "hidden"],
            "encoder_layouts": ["padded", "packed"],
            "shared_context": True,
            "lora": "peft-unmerged",
        }

    def supports(self, spec: ModelSpec, device: DeviceInfo) -> str | None:
        for backbone in (spec.backbone, *spec.towers.values()):
            if backbone.model_type not in models.ARCHITECTURES:
                return f"no native {backbone.model_type!r} backbone"
        if (
            device.accelerator != "cpu"
            and not device.bf16
            and spec.dtype.needs_gpu_bf16
        ):
            return f"{device.label} has no BF16 support"
        if device.accelerator == "cpu" and spec.dtype.cpu_weights == "float16":
            return "float16 runs on GPUs; use bfloat16 or float32 on a CPU"
        return None

    def read(
        self,
        spec: ModelSpec,
        accelerator: Accelerator,
        device: DeviceInfo,
        options: EngineOptions,
    ) -> Callable[[], NativeEngineModel]:
        """The checkpoint in host memory, in the dtypes the device holds; copying it there is the device work.

        On the CPU the host copy is the model's weights, and every CPU torch
        op of the process runs on the CPU's device thread (one OpenMP team),
        so all of the load is device work there.
        """
        if device.accelerator == "cpu":
            return partial(self.load, spec, accelerator, device, options)
        stacks = self._host(spec, accelerator, device, options)
        return partial(self._place, stacks, spec, accelerator, device, options)

    def load(
        self,
        spec: ModelSpec,
        accelerator: Accelerator,
        device: DeviceInfo,
        options: EngineOptions,
    ) -> NativeEngineModel:
        stacks = self._host(spec, accelerator, device, options)
        return self._place(stacks, spec, accelerator, device, options)

    def _host(
        self,
        spec: ModelSpec,
        accelerator: Accelerator,
        device: DeviceInfo,
        options: EngineOptions,
    ) -> HostStacks:
        if options.threads:
            torch.set_num_threads(options.threads)
        target = accelerator.torch_device(device)
        # A backbone held in a reduced dtype is read straight into it: the same
        # values as an FP32 read and a cast, without the FP32 copy in host memory.
        held = (
            spec.dtype.cpu_weights if target.type == "cpu" else spec.dtype.gpu_weights
        )
        dtype = getattr(torch, held) if held else torch.float32
        backbone_spec = spec.backbone
        backbone = build_on_meta(backbone_spec)
        load_backbone(
            backbone,
            backbone_spec.weight_files,
            backbone_spec.weight_prefix,
            dtype=dtype,
        )
        lora = backbone_spec.lora
        if lora is not None:
            if options.merge_lora:
                raise ValueError(
                    "merged LoRA changes answers; the runtime runs adapters unmerged"
                )
            with torch.device("meta"):
                attach(
                    backbone,
                    list(lora.target_modules),
                    lora.rank,
                    lora.alpha / lora.rank,
                )
            load_adapter(backbone, lora.weight_files)
        branches = {
            name: load_branch(backbone, backbone_spec, name)
            for name in backbone_spec.branches
        }
        towers = {name: load_tower(tower, dtype) for name, tower in spec.towers.items()}
        modules = (backbone, *branches.values(), *towers.values())
        leftovers = [
            name
            for module in modules
            for name, tensor in (*module.named_parameters(), *module.named_buffers())
            if tensor.is_meta
        ]
        if leftovers:
            raise ValueError(f"backbone parameters were not loaded: {leftovers[:3]}")
        residency = None
        for module in modules:
            if held:
                cast_parameters(module, dtype)
                continue
            module.float()
            if target.type != "cpu" and spec.dtype.bf16_resident:
                residency = keep_linear_bf16(module)
        return HostStacks(backbone, branches, towers, residency)

    def _place(
        self,
        stacks: HostStacks,
        spec: ModelSpec,
        accelerator: Accelerator,
        device: DeviceInfo,
        options: EngineOptions,
    ) -> NativeEngineModel:
        target = accelerator.torch_device(device)
        for module in (
            stacks.backbone,
            *stacks.branches.values(),
            *stacks.towers.values(),
        ):
            module.to(target).eval()
        kind = (
            spec.dtype.reduced_cpu if target.type == "cpu" else spec.dtype.reduced_gpu
        )
        return NativeEngineModel(
            stacks.backbone,
            accelerator,
            device,
            spec,
            options,
            stacks.residency,
            stacks.branches,
            kind if options.reduced_precision and spec.encoder else None,
            stacks.towers,
        )


def build_on_meta(spec: BackboneSpec) -> nn.Module:
    """The architecture without allocating weights; its computed buffers (rotary tables, indices) on the CPU."""
    with torch.device("meta"):
        module = models.build(spec.model_type, spec.config)
    if hasattr(module, "rotary_emb"):
        module.rotary_emb = type(module.rotary_emb)(spec.config)
    if hasattr(module, "computed_buffers"):
        cast(models.ComputedBuffers, module).computed_buffers()
    return module


def load_tower(spec: BackboneSpec, dtype: torch.dtype = torch.float32) -> nn.Module:
    """A tower (``ModelSpec.towers``): every tensor under its prefix must belong to it."""
    tower = build_on_meta(spec)
    load_backbone(
        tower, spec.weight_files, spec.weight_prefix, strict=True, dtype=dtype
    )
    return tower


def load_branch(backbone: nn.Module, spec: BackboneSpec, name: str) -> nn.Module:
    """A branch of a branched encoder: its own layer stack and final norm over the backbone's embedding."""
    branch = spec.branches[name]
    with torch.device("meta"):
        view = models.build(spec.model_type, spec.config)
    holder = nn.Module()
    holder.layers = view.layers
    holder.final_norm = view.final_norm
    load_backbone(
        holder,
        branch.weight_files,
        renames={
            f"{branch.layers}.": "layers.",
            f"{branch.final_norm}.": "final_norm.",
        },
    )
    view.embeddings = backbone.embeddings
    view.rotary_emb = backbone.rotary_emb
    return view
