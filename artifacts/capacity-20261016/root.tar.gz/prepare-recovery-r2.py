"""Offline validation and immutable evidence for the approved Laya recovery."""
import ast
from datetime import datetime, timezone
import fcntl
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/data/sdb/decision-model-eval')
BASE = ROOT / 'capacity-20261016'
SOURCE = BASE / 'source-r2'
SERVICE = SOURCE / 'deploy/docker/decision-eval'
SCRIPTS = SOURCE / 'evaluation/runner/scripts'
sys.path[:0] = [str(SERVICE), str(SCRIPTS)]
import decision_capacity_preflight as capacity
import public_decision_benchmark as benchmark
from deployment_probe import native_choice_request
from launch_reviewed import MODELS


def read(path):
    return json.loads(path.read_text())


def functions(path):
    return {node.name: ast.dump(node, include_attributes=False)
            for node in ast.parse(path.read_text()).body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}


with (ROOT / 'classification-20261015/classification.lock').open('a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert subprocess.check_output(['systemctl', 'show', 'decision-capacity-20261016.service',
                                   '--property=MainPID', '--value'], text=True).strip() == '0'
    assert not (BASE / 'run-002').exists()
    old = read(BASE / 'run-001/protocol.json')
    original = read(BASE / 'preparation.json')
    capacity.check_artifacts({str(BASE / name): digest for name, digest in original['source_sha256'].items()})
    capacity.check_artifacts(original['preserved_artifact_sha256'])
    state = read(BASE / 'run-001/status.json')
    models = old['models'][len(state['completed']):]
    assert models == ['laya-multilingual', 'd3-mini', 'vela-2.0-4b', 'neohorse-jev-4b',
                      'jeva-4b', 'd3-flash', 'clef-flash', 'vela-2.0-9b', 'jev-27b',
                      'pplx-decider-v1.1-27b', 'qwen3-30b-a3b-instruct-2507',
                      'qwen3.8-27b', 'qwen3.8-27b-thinking']
    paths = [SCRIPTS / 'decision_capacity_preflight.py', SCRIPTS / 'public_decision_benchmark.py',
             *SERVICE.glob('*.py'), SERVICE / 'nginx.native.conf.template']
    protocol = {**old, 'models': models,
                'source_sha256': {str(p): capacity.sha(p) for p in paths}}
    predecessor, preserved = capacity.capacity_predecessor(BASE / 'run-001', BASE / 'run-002',
                                                          models, protocol)
    data = read(BASE / 'dataset-final/protocol.json')
    for name, digest in data['files'].items():
        assert capacity.sha(BASE / 'dataset-final' / name) == digest
    assert capacity.sha(BASE / 'dataset-final/protocol.json') == old['dataset_protocol_sha256']
    jobs = benchmark.read_jsonl(BASE / 'dataset-final/inputs.private.jsonl')
    assert len(jobs) == 199
    audited = []
    for model in state['completed']:
        folder = BASE / 'run-001' / model
        blocks = []
        family, _, served = MODELS[model]
        deployment = read(folder / 'deployment.json')
        assert deployment['model'] == model and deployment['served_model'] == served
        assert read(folder / 'auth.json') == {'ready': 200, 'unauthorized': [401, 401, 401]}
        for repeat, order in enumerate(capacity.ORDERS, 1):
            for n in order:
                rows = benchmark.read_jsonl(folder / f'responses-n{n}-r{repeat}.jsonl')
                block = read(folder / f'block-n{n}-r{repeat}.json')
                assert len(rows) == 199
                assert block['peak_inflight'] == n and block['concurrency'] == n
                for index, (row, job) in enumerate(zip(rows, jobs)):
                    for key in ('case_id', 'fragment_id', 'input_sha256', 'chars'):
                        assert row[key] == job[key]
                    path, body = native_choice_request(family, {'model': served,
                        'state': job['state'], 'questions': capacity.QUESTIONS})
                    assert row['request_sha256'] == benchmark.digest(body) and row['path'] == path
                    assert row['calls'] == 1 and row['sequence'] == index
                    assert row['status'] == 'valid' and row['http_status'] == 200
                    assert row['prediction'] in ('relevant', 'irrelevant')
                    assert 0 < row['inflight_at_start'] <= n
                    assert row['elapsed_ms'] > 0 and row['ended_seconds'] > row['started_seconds']
                    assert row['ended_seconds'] <= block['wall_seconds']
                    assert abs(row['elapsed_ms'] - (row['ended_seconds'] - row['started_seconds']) * 1000) < 1
                basic = {k: block[k] for k in ('wall_seconds', 'peak_inflight', 'requests', 'concurrency', 'repeat')}
                assert capacity.block_summary(rows, basic) == block
                blocks.append({**basic, 'records': rows})
        assert read(folder / 'summary.json') == {'model': model, **capacity.summarize(blocks)}
        warmups = sorted(folder.glob('warmup-*.jsonl'))
        assert len(warmups) == 8
        assert all(len(benchmark.read_jsonl(p)) == 20 and
                   all(r['status'] == 'valid' and r['calls'] == 1 for r in benchmark.read_jsonl(p))
                   for p in warmups)
        audited.append({'model': model, 'measured_requests': 2388, 'failed': 0,
                        'input_request_hash_calls_and_metrics_checked': True,
                        'peak_concurrency': [1, 5, 10, 20]})
    failed = benchmark.read_jsonl(BASE / 'run-001/laya-multilingual/warmup-n20-r1.jsonl')
    assert len(failed) == 20 and sum(r['status'] == 'failed' for r in failed) == 3
    assert all(r['http_status'] == 503 for r in failed if r['status'] == 'failed')
    baseline = functions(ROOT / 'classification-20261015/source-r8/evaluation/runner/scripts/public_decision_benchmark.py')
    assert len(baseline) == 39 and baseline == functions(SCRIPTS / 'public_decision_benchmark.py')
    audits = [ROOT / 'classification-20261015' / relative for relative in (
        'audit-20261015/summary.json', 'qwen38-supplement-20261016/classification-audit.json',
        'qwen38-thinking-20261016/classification-audit.json')]
    expected_audits = ['4accc5327368197a99b9aa04b9c48751026b3ecfa8ad1be9b20c4b21e7e60729',
                       '5156b7ffe6d406d5a8a34f8dcbdfbadd5e716ad8f4485274f444edf89a14dbc7',
                       'dbb8cc70448bfb6372e1f513d35947324bd7e700d6957d333d74d9ee7230e8cf']
    for p, expected in zip(audits, expected_audits):
        assert capacity.sha(p) == expected
    artifact_sets = [read(p)['artifact_sha256'] for p in audits]
    union = {k: v for items in artifact_sets for k, v in items.items()}
    capacity.check_artifacts(union)
    assert len(union) == 200
    command = [str(ROOT / 'classification-20261015/venv/bin/python'), '-u',
               str(SCRIPTS / 'public_decision_benchmark.py'), 'local-capacity',
               '--root', str(ROOT), '--service-source', str(SERVICE),
               '--dataset', str(BASE / 'dataset-final'),
               '--env-file', str(ROOT / 'source-decision-v3-r3-20261012/.env'),
               '--output', str(BASE / 'run-002'), '--lock',
               str(ROOT / 'classification-20261015/classification.lock'),
               '--base-url', 'http://127.0.0.1:30889', '--port', '30889',
               '--timeout', '300', '--startup-timeout', '2400',
               '--after-run', str(BASE / 'run-001'), '--laya-max-concurrent', '32',
               '--prior-audits', *map(str, audits), '--models', *models]
    evidence = {
        'prepared_at_utc': datetime.now(timezone.utc).isoformat(),
        'reason': 'Owner-approved Laya admission-only correction after zero-measurement failure',
        'tests_passed': 100, 'predecessor': predecessor, 'models': models,
        'command': command, 'systemd_unit': 'decision-capacity-20261016-r2.service',
        'log': str(BASE / 'runner-r2.log'), 'dataset_protocol_sha256': capacity.sha(BASE / 'dataset-final/protocol.json'),
        'source_sha256': {str(p): capacity.sha(p) for p in SOURCE.rglob('*')
                          if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts},
        'preserved_artifact_sha256': preserved,
        'old_runner_log_sha256': capacity.sha(BASE / 'runner.log'),
        'completed_configurations_audited': audited,
        'classification_artifact_counts': [len(s) for s in artifact_sets],
        'classification_artifacts_union': len(union), 'classification_functions_ast_equal': 39,
        'capacity_measurement_functions_ast_equal': 7,
        'prior_laya': {'measured_requests': 0, 'failed_warmup_n': 20, 'warmup_http_503': 3},
        'laya_override': {'http_admission_limit': 32, 'gpu_execution_unchanged': True,
                          'single_request_executor_workers': 1, 'cross_request_batching': False},
        'new_inference_calls': 0, 'formal_classification_calls': 0, 'formal_passage_calls': 0,
    }
    capacity.save(BASE / 'preparation-r2.json', evidence)
    print(json.dumps({k: evidence[k] for k in ('prepared_at_utc', 'tests_passed',
        'completed_configurations_audited', 'classification_artifacts_union',
        'classification_functions_ast_equal', 'capacity_measurement_functions_ast_equal')}))
